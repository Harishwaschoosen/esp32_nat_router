import type { AppState, Deal, Founder, Settings, Startup } from '@/types';

const KEY = 'founderx_state_v1';

const defaultFounder: Founder = {
  name: '',
  company: '',
};

const defaultSettings: Settings = {
  darkMode: true,
  sound: true,
  notifications: true,
};

export function defaultState(): AppState {
  return {
    startups: [],
    currentStartup: null,
    currentInvestor: null,
    deal: null,
    founder: defaultFounder,
    settings: defaultSettings,
  };
}

export function loadState(): AppState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw) as Partial<AppState>;
    return {
      ...defaultState(),
      ...parsed,
      settings: { ...defaultSettings, ...parsed.settings },
      founder: { ...defaultFounder, ...parsed.founder },
    };
  } catch {
    return defaultState();
  }
}

export function saveState(state: AppState): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    // ignore quota / serialization errors
  }
}

export function addStartup(state: AppState, startup: Startup): AppState {
  const startups = [startup, ...state.startups].slice(0, 12);
  return { ...state, startups, currentStartup: startup };
}

export function closeDeal(state: AppState, deal: Deal): AppState {
  return { ...state, deal, currentInvestor: null };
}

export function clearCurrent(state: AppState): AppState {
  return { ...state, currentStartup: null, currentInvestor: null };
}

export function updateFounder(state: AppState, founder: Founder): AppState {
  return { ...state, founder: { ...state.founder, ...founder } };
}

export function updateSettings(state: AppState, settings: Partial<Settings>): AppState {
  return { ...state, settings: { ...state.settings, ...settings } };
}

export function resetAll(): void {
  try {
    localStorage.removeItem(KEY);
  } catch {
    // ignore
  }
}
