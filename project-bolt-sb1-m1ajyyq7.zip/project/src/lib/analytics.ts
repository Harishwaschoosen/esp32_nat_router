import type { Startup } from '@/types';

export interface AnalyticsSeries {
  month: string;
  revenue: number;
  expenses: number;
  profit: number;
  customers: number;
}

const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function buildAnalytics(startup: Startup | null): {
  series: AnalyticsSeries[];
  totals: { revenue: number; funding: number; customers: number; growth: number; expenses: number; profit: number };
} {
  const base = startup?.monthlyRevenue ?? 4200;
  const funding = startup?.fundingRequired ?? 250000;
  const series: AnalyticsSeries[] = months.map((m, i) => {
    const ramp = 1 + i * 0.16 + Math.sin(i) * 0.04;
    const revenue = Math.round((base * ramp) / 10) * 10;
    const expenses = Math.round((revenue * 0.62 + 1200) / 10) * 10;
    const profit = revenue - expenses;
    const customers = Math.round((revenue / 38) * (1 + i * 0.05));
    return { month: m, revenue, expenses, profit, customers };
  });

  const revenue = series.reduce((s, x) => s + x.revenue, 0);
  const expenses = series.reduce((s, x) => s + x.expenses, 0);
  const profit = revenue - expenses;
  const customers = series[series.length - 1].customers;
  const growth = Math.round(((series[11].revenue - series[0].revenue) / Math.max(series[0].revenue, 1)) * 100);
  const totals = { revenue, funding, customers, growth, expenses, profit };
  return { series, totals };
}

export function growthPie(series: AnalyticsSeries[]) {
  const segments = [0, 3, 6, 9, 11].map((i) => ({
    name: `Q${Math.floor(i / 3) + 1}`,
    value: series.slice(i, i + 3).reduce((s, x) => s + x.customers, 0),
  }));
  return segments;
}
