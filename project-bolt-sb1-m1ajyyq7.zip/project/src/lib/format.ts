export function formatMoney(n: number, compact = false): string {
  if (compact) {
    if (n >= 1_000_000) return `$${(n / 1_000_000).toFixed(1).replace(/\.0$/, '')}M`;
    if (n >= 1_000) return `$${(n / 1_000).toFixed(1).replace(/\.0$/, '')}k`;
  }
  return `$${n.toLocaleString('en-US')}`;
}

export function formatDate(ts: number): string {
  return new Date(ts).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
}

export function shortDate(ts: number): string {
  return new Date(ts).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
  });
}

export function certId(founder: string, startup: string): string {
  const a = (founder || 'FX').slice(0, 3).toUpperCase();
  const b = (startup || 'SU').slice(0, 3).toUpperCase();
  const n = (Date.now() % 100000).toString().padStart(5, '0');
  return `FX-${a}-${b}-${n}`;
}
