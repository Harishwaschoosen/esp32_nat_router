import type { Difficulty, ExperienceLevel, Startup, StartupForm } from '@/types';

const prefixes = [
  'Food', 'Edu', 'Agro', 'Eco', 'Medi', 'Travel', 'Farm', 'Quick', 'Game', 'Skill',
  'Fit', 'Pay', 'Cloud', 'Nova', 'Lumen', 'Pulse', 'Zen', 'Urban', 'Green', 'Smart',
  'Meta', 'Cyber', 'Bio', 'Space', 'Auto', 'Vivid', 'Quantum', 'Forge', 'Hive', 'Peak',
];

const suffixes = [
  'ify', 'Spark', 'Link', 'Bottle', 'Sense', 'Go', 'Flow', 'Chef', 'Verse', 'Bridge',
  'Hub', 'Lab', 'Base', 'Pod', 'Nest', 'Loop', 'Wave', 'Beam', 'Grid', 'Stack',
  'Drop', 'Pilot', 'Quest', 'Forge', 'Mint', 'Scope', 'Wave', 'Bit', 'Mate', 'X',
];

const problems = [
  'Millions of people struggle to find healthy, affordable meals on a busy schedule, relying on expensive takeout and processed food.',
  'Small businesses lose 40% of potential customers because they cannot respond to messages fast enough across multiple platforms.',
  'Students spend hundreds of hours on generic courses that do not match their actual learning pace or career goals.',
  'Remote teams suffer from misalignment and burnout, with no simple way to track energy and focus in real time.',
  'Farmers in emerging markets lose up to 30% of their harvest to broken supply chains and lack of direct buyer access.',
  'Fitness beginners give up within 3 months because generic plans ignore their body type, schedule, and motivation triggers.',
  'Freelancers waste 12+ hours a week on invoicing, chasing payments, and switching between disconnected tools.',
  'Patients wait weeks for specialist appointments while early symptoms go untracked and unshared with their doctor.',
  'Travelers overspend and miss authentic experiences because recommendation apps push paid sponsor listings.',
  'Creators cannot prove their reach to brands without paying for expensive analytics suites they barely use.',
  'Local shops have no affordable way to launch an online store without hiring a developer or paying high platform fees.',
  'Parents struggle to find safe, educational screen-time content that actually adapts to their child\'s reading level.',
];

const solutions = [
  'An AI-powered mobile app that builds a personalized weekly meal plan, generates a grocery list, and connects to local grocery delivery.',
  'A unified inbox that auto-replies with AI-trained responses and routes urgent leads to the right team member in seconds.',
  'An adaptive learning platform that builds a skill graph from each student\'s answers and serves micro-lessons at the right difficulty.',
  'A lightweight team dashboard that syncs with calendars and wearables to surface energy trends and suggest focus blocks.',
  'A mobile marketplace connecting farmers directly to buyers with transparent pricing and shared logistics routing.',
  'A fitness app that runs a 5-question daily check-in and adjusts workouts to energy, sleep, and motivation in real time.',
  'An all-in-one freelancer OS with smart invoices, automated follow-ups, and a unified client timeline in one dashboard.',
  'A symptom-tracking wearable that flags early warning patterns and securely shares a summary with the patient\'s specialist.',
  'A community-curated travel app that ranks experiences by locals\' votes and hides anything that is paid placement.',
  'A creator credentials platform that mints verifiable reach badges from connected social accounts, free for creators.',
  'A no-code store builder that launches a branded mobile storefront from a single product photo and a WhatsApp number.',
  'An adaptive kids reading app that levels every story to the child\'s vocabulary and rewards depth over minutes spent.',
];

const models = [
  'Freemium SaaS with a Pro tier at $12/month and annual enterprise contracts.',
  'Subscription at $19/month per user with a 14-day free trial and team discounts.',
  'Transaction-based: 6% take rate on each completed booking or order.',
  'B2B SaaS at $49/seat/month plus a one-time onboarding fee of $1,200.',
  'Marketplace with 12% commission plus optional promoted-listing ads.',
  'Hardware + companion app, with recurring $8/month premium insights subscription.',
];

const revenueStreamPool = [
  'Monthly subscriptions',
  'Annual enterprise licenses',
  'Transaction fees',
  'In-app premium features',
  'Sponsored placements',
  'API access for partners',
  'White-label deployments',
  'Certification courses',
];

const marketingPlans = [
  'Content marketing with weekly founder-led LinkedIn posts, SEO landing pages, and a referral program giving 30 days free.',
  'TikTok and Instagram Reels series showing real customer wins, plus micro-influencer partnerships in the first 90 days.',
  'Community-led growth via a free Discord, weekly AMAs, and a launch on Product Hunt with a targeted email waitlist.',
  'Outbound to 200 ICP accounts per month with personalized Loom videos, supported by a webinar series and case studies.',
  'Local field marketing with pop-up events in 3 launch cities, partnered with regional radio and WhatsApp community groups.',
  'App Store Optimization with a freemium funnel, rewarded sharing inside the app, and a campus ambassador program.',
];

const countries = ['USA', 'India', 'UK', 'Brazil', 'Germany', 'Nigeria', 'Singapore', 'Canada', 'UAE', 'Australia'];

function pick<T>(arr: T[], seed: number): T {
  return arr[Math.abs(Math.floor(seed * 0.137)) % arr.length];
}

function pickN<T>(arr: T[], n: number, seed: number): T[] {
  const out: T[] = [];
  const used = new Set<number>();
  let s = seed;
  while (out.length < n && used.size < arr.length) {
    s = (s * 9301 + 49297) % 233280;
    const idx = Math.floor((s / 233280) * arr.length);
    if (!used.has(idx)) {
      used.add(idx);
      out.push(arr[idx]);
    }
  }
  return out;
}

function hashSeed(str: string): number {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (h * 31 + str.charCodeAt(i)) >>> 0;
  }
  return h + Date.now() % 100000;
}

function makeName(seed: number): string {
  const p = pick(prefixes, seed);
  const s = pick(suffixes, seed + 7);
  if (s === 'ify' || s === 'X' || s === 'Bit' || s === 'Mate') return `${p}${s.toLowerCase()}`;
  return `${p}${s}`;
}

function difficultyFromScore(score: number): Difficulty {
  if (score >= 88) return 'Easy';
  if (score >= 72) return 'Medium';
  if (score >= 55) return 'Hard';
  return 'Very Hard';
}

function scoreFromForm(form: StartupForm): number {
  let base = 60;
  if (form.experience === 'Experienced') base += 8;
  else if (form.experience === 'Serial Founder') base += 12;
  else if (form.experience === 'Intermediate') base += 4;
  if (form.budget >= 50000) base += 6;
  else if (form.budget >= 10000) base += 3;
  if (form.idea.trim().length > 12) base += 4;
  if (form.targetCustomers.trim().length > 5) base += 4;
  const jitter = Math.floor(Math.random() * 14);
  return Math.max(48, Math.min(98, base + jitter));
}

function swotFor(form: StartupForm, score: number) {
  const exp = form.experience;
  return {
    strengths: [
      exp === 'Serial Founder' || exp === 'Experienced' ? 'Strong founder-market fit and prior exit experience.' : 'Fresh perspective with low bias and high adaptability.',
      score >= 75 ? 'Healthy success probability with a clear value loop.' : 'Lean cost structure keeps downside small.',
      form.budget >= 20000 ? 'Sufficient early capital to reach first revenue.' : 'Capital-efficient model that can ship an MVP fast.',
    ],
    weaknesses: [
      form.budget < 10000 ? 'Limited runway may force early fundraising under pressure.' : 'Customer acquisition cost is unproven at scale.',
      'Brand awareness starts at zero in a crowded attention market.',
      'Single-founder dependency risk on product and fundraising simultaneously.',
    ],
    opportunities: [
      `The ${form.industry || 'target'} market is growing 18-24% year over year.`,
      'AI tooling has collapsed the cost of building and iterating on a v1 product.',
      'Underserved adjacent segment: enterprise teams looking for a lighter alternative.',
    ],
    threats: [
      'A well-funded incumbent could ship a competing feature within 6-9 months.',
      'Regulatory shifts in data privacy may raise compliance costs.',
      'Macroeconomic tightening could slow B2B purchasing cycles.',
    ],
  };
}

export function generateStartup(form: StartupForm): Startup {
  const seed = hashSeed(`${form.idea}|${form.industry}|${form.founderName}|${Math.random()}`);
  const score = scoreFromForm(form);
  const name = makeName(seed);
  const problem = pick(problems, seed);
  const solution = pick(solutions, seed + 3);
  const model = pick(models, seed + 11);
  const revenueStreams = pickN(revenueStreamPool, 3, seed + 5);
  const marketingPlan = pick(marketingPlans, seed + 19);

  const startupCost = Math.max(1500, Math.round((form.budget * 0.6 + 4000 + (seed % 9000)) / 100) * 100);
  const monthlyRevenue = Math.max(800, Math.round((startupCost * 0.18 + 1200 + (seed % 4000)) / 50) * 50);
  const teamSize = 2 + (seed % 7);
  const fundingRequired = Math.max(25000, Math.round((startupCost * 4 + 20000) / 5000) * 5000);

  const marketSize = `$${(1.5 + (seed % 8) * 0.6).toFixed(1)}B`;
  const competitionPool = ['Low — niche is underserved', 'Medium — a few slow incumbents', 'High — fast-moving category', 'Moderate — room for a premium player'];
  const riskPool = ['Low risk', 'Medium risk', 'Elevated risk', 'Calculated risk'];
  const breakEvenPool = ['8-12 months', '12-18 months', '18-24 months', '6-9 months'];

  return {
    id: `su_${Date.now().toString(36)}${Math.floor(Math.random() * 1000)}`,
    createdAt: Date.now(),
    form,
    name,
    problem,
    solution,
    targetCustomers: form.targetCustomers || pick([
      'Busy professionals aged 25-45 in metro areas',
      'Small business owners with under 20 employees',
      'College students and early-career learners',
      'Health-conscious adults aged 30-55',
      'Independent creators with 10k-100k followers',
    ], seed),
    businessModel: model,
    revenueStreams,
    startupCost,
    monthlyRevenue,
    marketingPlan,
    teamSize,
    fundingRequired,
    difficulty: difficultyFromScore(score),
    successProbability: Math.min(97, Math.max(45, score - 3 + (seed % 6))),
    score,
    swot: swotFor(form, score),
    metrics: {
      startupCost,
      marketSize,
      competition: pick(competitionPool, seed + 2),
      riskLevel: pick(riskPool, seed + 4),
      marketingStrategy: marketingPlan,
      fundingAdvice: fundingRequired > 150000
        ? 'Consider a pre-seed round of $250k with a 10% equity target, then raise seed at $1.5M post-money.'
        : 'Bootstrap to $10k MRR, then raise a small seed of $500k on momentum rather than projections.',
      breakEvenTime: pick(breakEvenPool, seed + 6),
    },
  };
}

export const industries = [
  'Food & Beverage', 'Education', 'Agriculture', 'Sustainability', 'HealthTech',
  'Travel', 'Fitness', 'Fintech', 'SaaS', 'Gaming', 'Creator Economy', 'E-commerce',
  'AI', 'Climate', 'Logistics', 'Real Estate',
];

export const experienceLevels: ExperienceLevel[] = ['Beginner', 'Intermediate', 'Experienced', 'Serial Founder'];

export const countryList = countries;
