import type { Investor, Startup } from '@/types';

interface InvestorProfile {
  name: string;
  avatar: string;
  firm: string;
  focus: string;
}

const profiles: InvestorProfile[] = [
  { name: 'Sarah Chen', avatar: 'SC', firm: 'Velvet Capital', focus: 'Consumer & SaaS' },
  { name: 'Kevin Park', avatar: 'KP', firm: 'NorthStar Ventures', focus: 'AI & Frontier Tech' },
  { name: 'Mark Delgado', avatar: 'MD', firm: 'Summit Partners', focus: 'Fintech & Marketplaces' },
  { name: 'Anita Rao', avatar: 'AR', firm: 'Phoenix Fund', focus: 'Health & Climate' },
  { name: 'Raj Mehta', avatar: 'RM', firm: 'Horizon Labs', focus: 'Emerging Markets' },
  { name: 'Elena Volkov', avatar: 'EV', firm: 'Cobalt Ventures', focus: 'Creator Economy' },
  { name: 'Tomás Silva', avatar: 'TS', firm: 'Andes Capital', focus: 'Logistics & B2B' },
  { name: 'Nadia Hassan', avatar: 'NH', firm: 'Lighthouse Fund', focus: 'EdTech & AI' },
];

const positiveFeedback = [
  "I'm investing because your market is growing and your unit economics make sense from day one.",
  "This has unicorn potential. Your moat is real and your acquisition channel is repeatable.",
  "Your founder-market fit stands out. I back founders who feel the pain they are solving.",
  "I like the lean burn and the clear path to $1M ARR. Here is what I am willing to offer.",
  "The traction narrative is tight. I want to be in this round before it gets crowded.",
];

const negativeFeedback = [
  "I'm out because customer acquisition costs look too high for this category right now.",
  "The idea is interesting but the moat is thin — an incumbent could copy this in a quarter.",
  "I am passing. Your valuation expectation is ahead of where your traction supports today.",
  "Not for me at this stage. Come back when you have 90 days of cohort retention data.",
  "The market is real but I do not see a repeatable acquisition loop yet. I will sit this one out.",
];

const improvementTips = [
  'Cut customer acquisition cost by building a community-led growth loop before paid spend.',
  'Ship a tighter MVP that tests your single riskiest assumption in 30 days, not 90.',
  'Add a sticky integration or data flywheel that is hard for an incumbent to copy quickly.',
  'Raise a smaller bridge on momentum terms instead of pushing for a high valuation now.',
  'Narrow your ICP to one niche, win it, then expand — breadth too early kills focus.',
  'Build 90 days of cohort retention data so investors can model LTV with confidence.',
  'Lock in 3 design partners with paid LOIs before pitching a priced round.',
];

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function generateInvestor(startup: Startup): Investor {
  const profile = pick(profiles);
  const positive = startup.score >= 68 && Math.random() > 0.18;
  const baseAmount = Math.max(50000, Math.round((startup.fundingRequired * 0.4 + 40000) / 5000) * 5000);
  const amount = positive
    ? baseAmount + Math.floor(Math.random() * 5) * 25000
    : 0;
  const equity = positive
    ? Math.max(7, Math.min(22, Math.round((amount / Math.max(startup.fundingRequired * 4, 400000)) * 100 * 10) / 10 + 4))
    : 0;
  const valuation = equity > 0 ? Math.round((amount / (equity / 100)) ) : 0;

  return {
    id: `inv_${Date.now().toString(36)}`,
    name: profile.name,
    avatar: profile.avatar,
    firm: profile.firm,
    focus: profile.focus,
    feedback: positive ? pick(positiveFeedback) : pick(negativeFeedback),
    amount,
    equity,
    reason: positive
      ? `Backing ${startup.name} at a ${(valuation / 1_000_000).toFixed(1)}M post-money valuation.`
      : 'Declined to invest at this stage.',
    positive,
  };
}

export function getImprovementTips(): string[] {
  const tips = [...improvementTips];
  const out: string[] = [];
  while (out.length < 3 && tips.length) {
    const i = Math.floor(Math.random() * tips.length);
    out.push(tips.splice(i, 1)[0]);
  }
  return out;
}
