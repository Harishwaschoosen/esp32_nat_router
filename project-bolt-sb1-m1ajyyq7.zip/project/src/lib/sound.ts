let ctx: AudioContext | null = null;

function getCtx(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!ctx) {
    try {
      ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    } catch {
      return null;
    }
  }
  return ctx;
}

function tone(freq: number, duration: number, type: OscillatorType = 'sine', when = 0, gain = 0.06): void {
  const c = getCtx();
  if (!c) return;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, c.currentTime + when);
  g.gain.exponentialRampToValueAtTime(gain, c.currentTime + when + 0.01);
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + when + duration);
  osc.connect(g);
  g.connect(c.destination);
  osc.start(c.currentTime + when);
  osc.stop(c.currentTime + when + duration + 0.02);
}

export const sounds = {
  click(): void {
    tone(420, 0.08, 'triangle', 0, 0.04);
  },
  success(): void {
    tone(523.25, 0.16, 'sine', 0, 0.07);
    tone(659.25, 0.18, 'sine', 0.12, 0.07);
    tone(783.99, 0.26, 'sine', 0.24, 0.07);
  },
  generate(): void {
    tone(330, 0.1, 'sawtooth', 0, 0.035);
    tone(440, 0.12, 'sawtooth', 0.1, 0.035);
  },
  reject(): void {
    tone(196, 0.18, 'sine', 0, 0.05);
    tone(146.83, 0.24, 'sine', 0.14, 0.05);
  },
  toggle(): void {
    tone(660, 0.06, 'square', 0, 0.025);
  },
};

export function play(sound: keyof typeof sounds, enabled: boolean): void {
  if (!enabled) return;
  try {
    sounds[sound]();
  } catch {
    // ignore audio errors
  }
}
