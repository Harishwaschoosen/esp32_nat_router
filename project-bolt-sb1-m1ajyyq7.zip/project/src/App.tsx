import { AnimatePresence, motion } from 'framer-motion';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { FloatingBackground } from '@/components/FloatingBackground';
import { BottomNav } from '@/components/BottomNav';
import { ToastHost } from '@/components/ToastHost';
import { PWAInstallPrompt } from '@/components/PWAInstallPrompt';
import { AppProvider } from '@/context/AppContext';
import { SplashPage } from '@/pages/SplashPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { GeneratorPage } from '@/pages/GeneratorPage';
import { CoachPage } from '@/pages/CoachPage';
import { SharkTankPage } from '@/pages/SharkTankPage';
import { CertificatePage } from '@/pages/CertificatePage';
import { AnalyticsPage } from '@/pages/AnalyticsPage';
import { ProfilePage } from '@/pages/ProfilePage';
import { SettingsPage } from '@/pages/SettingsPage';
import { AboutPage } from '@/pages/AboutPage';
import { SuccessPage } from '@/pages/SuccessPage';
import { NotFoundPage } from '@/pages/NotFoundPage';

function AnimatedRoutes() {
  const location = useLocation();
  const isWarm = location.pathname === '/certificate' || location.pathname === '/about';

  return (
    <>
      <FloatingBackground variant={isWarm ? 'warm' : 'default'} />
      <AnimatePresence mode="wait">
        <motion.main
          key={location.pathname}
          initial={{ opacity: 0, y: 18, filter: 'blur(6px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          exit={{ opacity: 0, y: -12, filter: 'blur(6px)' }}
          transition={{ duration: 0.45, ease: [0.22, 1, 0.36, 1] }}
        >
          <Routes location={location}>
            <Route path="/" element={<SplashPage />} />
            <Route path="/dashboard" element={<DashboardPage />} />
            <Route path="/generate" element={<GeneratorPage />} />
            <Route path="/coach" element={<CoachPage />} />
            <Route path="/sharktank" element={<SharkTankPage />} />
            <Route path="/certificate" element={<CertificatePage />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="/settings" element={<SettingsPage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/success" element={<SuccessPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </motion.main>
      </AnimatePresence>
      <BottomNav />
      <ToastHost />
      <PWAInstallPrompt />
    </>
  );
}

export default function App() {
  return (
    <AppProvider>
      <BrowserRouter>
        <AnimatedRoutes />
      </BrowserRouter>
    </AppProvider>
  );
}
