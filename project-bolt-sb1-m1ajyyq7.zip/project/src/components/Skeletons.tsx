import { Skeleton } from './Skeleton';

export function StatSkeleton() {
  return (
    <div className="glass rounded-2xl p-4">
      <Skeleton className="h-3 w-20" />
      <Skeleton className="mt-3 h-7 w-24" />
      <Skeleton className="mt-3 h-2 w-full" />
    </div>
  );
}

export function CardSkeleton() {
  return (
    <div className="glass rounded-3xl p-5">
      <Skeleton className="h-5 w-2/3" />
      <Skeleton className="mt-4 h-3 w-full" />
      <Skeleton className="mt-2 h-3 w-5/6" />
      <Skeleton className="mt-2 h-3 w-4/6" />
      <div className="mt-4 flex gap-2">
        <Skeleton className="h-9 w-28 rounded-2xl" />
        <Skeleton className="h-9 w-28 rounded-2xl" />
      </div>
    </div>
  );
}

export function ChartSkeleton() {
  return (
    <div className="glass rounded-3xl p-5">
      <Skeleton className="h-4 w-32" />
      <Skeleton className="mt-4 h-40 w-full" />
    </div>
  );
}

export function ListSkeleton({ count = 3 }: { count?: number }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="glass rounded-2xl p-4">
          <div className="flex gap-3">
            <Skeleton className="h-12 w-12 rounded-2xl" />
            <div className="flex-1">
              <Skeleton className="h-4 w-2/3" />
              <Skeleton className="mt-2 h-3 w-1/2" />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
