import { motion } from 'framer-motion';
import type { ReactNode } from 'react';
import { TopBar } from './TopBar';

interface PageLayoutProps {
  children: ReactNode;
  title: string;
  subtitle?: string;
  back?: boolean;
  backTo?: string;
  accent?: 'brand' | 'aqua' | 'warm' | 'grape';
  showSettings?: boolean;
}

export function PageLayout({
  children,
  title,
  subtitle,
  back = true,
  backTo = '/dashboard',
  accent = 'brand',
  showSettings = false,
}: PageLayoutProps) {
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col px-4 pb-28 pt-5 sm:max-w-lg">
      <TopBar title={title} subtitle={subtitle} back={back} backTo={backTo} accent={accent} showSettings={showSettings} />
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex-1"
      >
        {children}
      </motion.div>
    </div>
  );
}
