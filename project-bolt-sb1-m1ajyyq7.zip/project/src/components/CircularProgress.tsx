import { useEffect, useRef, useState } from 'react';
import { animate, useInView } from 'framer-motion';

interface CircularProgressProps {
  value: number;
  max?: number;
  size?: number;
  stroke?: number;
  label?: string;
  sublabel?: string;
  gradientFrom?: string;
  gradientTo?: string;
  trackColor?: string;
}

export function CircularProgress({
  value,
  max = 100,
  size = 132,
  stroke = 12,
  sublabel,
  gradientFrom = '#7c8cff',
  gradientTo = '#22e3f0',
  trackColor = 'rgba(255,255,255,0.08)',
}: CircularProgressProps) {
  const ref = useRef<SVGSVGElement>(null);
  const inView = useInView(ref, { once: true, margin: '-30px' });
  const [progress, setProgress] = useState(0);
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const pct = Math.max(0, Math.min(1, value / max));
  const gradientId = `cpg-${Math.round(value * 1000)}-${size}`;

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, pct, {
      duration: 1.6,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setProgress(v),
    });
    return () => controls.stop();
  }, [inView, pct]);

  const offset = circumference - progress * circumference;

  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg ref={ref} width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={gradientFrom} />
            <stop offset="100%" stopColor={gradientTo} />
          </linearGradient>
        </defs>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={trackColor}
          strokeWidth={stroke}
          fill="none"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={`url(#${gradientId})`}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ filter: 'drop-shadow(0 0 6px rgba(124,140,255,0.5))' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-display text-2xl font-bold text-white">
          {Math.round(progress * max)}
        </span>
        {sublabel && <span className="mt-0.5 text-[10px] uppercase tracking-wider text-brand-200/60">{sublabel}</span>}
      </div>
    </div>
  );
}
