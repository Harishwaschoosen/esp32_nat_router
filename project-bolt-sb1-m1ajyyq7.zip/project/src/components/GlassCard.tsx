import { motion } from 'framer-motion';
import type { ReactNode } from 'react';

interface GlassCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: 'none' | 'brand' | 'aqua' | 'success' | 'grape';
  delay?: number;
  elevated?: boolean;
}

const glowMap = {
  none: '',
  brand: 'hover:shadow-glow',
  aqua: 'hover:shadow-glow-aqua',
  success: 'hover:shadow-glow-success',
  grape: 'hover:shadow-glow-grape',
} as const;

export function GlassCard({
  children,
  className = '',
  hover = false,
  glow = 'none',
  delay = 0,
  elevated = false,
}: GlassCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] }}
      whileHover={hover ? { y: -5 } : undefined}
      className={`${elevated ? 'glass-elevated' : 'glass'} rounded-3xl ${glowMap[glow]} ${
        hover ? 'transition-all duration-300' : ''
      } ${className}`}
    >
      {children}
    </motion.div>
  );
}
