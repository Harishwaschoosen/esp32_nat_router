import canvasConfetti from 'canvas-confetti';

const colors = ['#7c8cff', '#8b5cf6', '#a5b2ff', '#22e3f0', '#34f5b0', '#ffffff'];

export function fireConfetti(): void {
  const end = Date.now() + 1000;

  (function frame() {
    canvasConfetti({
      particleCount: 5,
      angle: 60,
      spread: 70,
      origin: { x: 0, y: 0.75 },
      colors,
      disableForReducedMotion: true,
    });
    canvasConfetti({
      particleCount: 5,
      angle: 120,
      spread: 70,
      origin: { x: 1, y: 0.75 },
      colors,
      disableForReducedMotion: true,
    });
    if (Date.now() < end) requestAnimationFrame(frame);
  })();

  canvasConfetti({
    particleCount: 140,
    spread: 100,
    startVelocity: 50,
    origin: { x: 0.5, y: 0.62 },
    colors,
    disableForReducedMotion: true,
  });
}
