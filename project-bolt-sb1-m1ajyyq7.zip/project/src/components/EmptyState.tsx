import { motion } from 'framer-motion';
import type { ReactNode } from 'react';

interface EmptyStateProps {
  icon: ReactNode;
  title: string;
  message: string;
  action?: ReactNode;
}

export function EmptyState({ icon, title, message, action }: EmptyStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass flex flex-col items-center rounded-3xl p-8 text-center"
    >
      <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-white/5 text-brand-200/60">{icon}</div>
      <h3 className="mt-4 font-display text-lg font-bold text-white">{title}</h3>
      <p className="mt-1 text-sm text-brand-200/60">{message}</p>
      {action && <div className="mt-5">{action}</div>}
    </motion.div>
  );
}
