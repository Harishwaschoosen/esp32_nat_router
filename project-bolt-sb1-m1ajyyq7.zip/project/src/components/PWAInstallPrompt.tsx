import { motion, AnimatePresence } from 'framer-motion';
import { Download, X, Rocket } from 'lucide-react';
import { useEffect, useState } from 'react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function PWAInstallPrompt() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
      setVisible(true);
    };
    window.addEventListener('beforeinstallprompt', handler);
    return () => window.removeEventListener('beforeinstallprompt', handler);
  }, []);

  const install = async () => {
    if (!deferred) return;
    await deferred.prompt();
    await deferred.userChoice;
    setDeferred(null);
    setVisible(false);
  };

  const dismiss = () => {
    setVisible(false);
    setDeferred(null);
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 40 }}
          transition={{ type: 'spring', stiffness: 300, damping: 26 }}
          className="fixed inset-x-0 bottom-24 z-50 mx-auto w-full max-w-md px-4 sm:max-w-lg"
        >
          <div className="glass-elevated flex items-center gap-3 rounded-3xl p-4 shadow-glow-lg">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-brand-gradient-hero shadow-glow">
              <Rocket className="h-5 w-5 text-white" />
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">Install FounderX AI</p>
              <p className="text-[11px] text-brand-200/60">Add to your home screen for the full app experience.</p>
            </div>
            <button
              onClick={install}
              className="flex h-10 w-10 items-center justify-center rounded-2xl bg-brand-gradient-hero text-white shadow-glow transition active:scale-90"
              aria-label="Install app"
            >
              <Download className="h-5 w-5" />
            </button>
            <button
              onClick={dismiss}
              className="text-brand-200/50 transition hover:text-white"
              aria-label="Dismiss"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
