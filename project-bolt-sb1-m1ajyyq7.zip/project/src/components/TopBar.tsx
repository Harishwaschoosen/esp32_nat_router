import { motion } from 'framer-motion';
import { ChevronLeft, Settings } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

interface TopBarProps {
  title: string;
  subtitle?: string;
  back?: boolean;
  backTo?: string;
  accent?: 'brand' | 'aqua' | 'warm' | 'grape';
  showSettings?: boolean;
}

const accentMap = {
  brand: 'text-gradient',
  aqua: 'text-gradient-2',
  warm: 'text-gradient-warm',
  grape: 'text-transparent bg-clip-text bg-gradient-to-r from-grape-300 to-brand-300',
};

export function TopBar({ title, subtitle, back = true, backTo = '/dashboard', accent = 'brand', showSettings = false }: TopBarProps) {
  const navigate = useNavigate();
  return (
    <motion.header
      initial={{ opacity: 0, y: -16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="flex items-center justify-between gap-3 pb-5"
    >
      <div className="flex items-center gap-3">
        {back && (
          <button
            onClick={() => navigate(backTo)}
            className="glass flex h-10 w-10 items-center justify-center rounded-2xl text-brand-100 transition hover:bg-white/10 active:scale-95"
            aria-label="Back"
          >
            <ChevronLeft className="h-5 w-5" />
          </button>
        )}
        <div>
          <p className="text-[11px] uppercase tracking-[0.2em] text-brand-200/50">FounderX AI</p>
          <h1 className={`font-display text-2xl font-bold leading-tight ${accentMap[accent]}`}>{title}</h1>
          {subtitle && <p className="text-xs text-brand-200/60">{subtitle}</p>}
        </div>
      </div>
      {showSettings && (
        <button
          onClick={() => navigate('/settings')}
          className="glass flex h-10 w-10 items-center justify-center rounded-2xl text-brand-100 transition hover:bg-white/10 active:scale-95"
          aria-label="Settings"
        >
          <Settings className="h-5 w-5" />
        </button>
      )}
    </motion.header>
  );
}
