import { motion } from 'framer-motion';
import type { ButtonHTMLAttributes, ReactNode } from 'react';

interface GlowButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  variant?: 'primary' | 'aqua' | 'grape' | 'ghost' | 'success' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
}

const variantMap: Record<NonNullable<GlowButtonProps['variant']>, string> = {
  primary:
    'bg-brand-gradient text-white shadow-glow hover:shadow-glow-lg',
  grape:
    'bg-gradient-to-br from-brand-400 to-grape-500 text-white shadow-glow-grape hover:shadow-[0_0_40px_rgba(139,92,246,0.65)]',
  aqua: 'bg-gradient-to-br from-aqua-400 to-aqua-600 text-ink-950 shadow-glow-aqua hover:shadow-[0_0_32px_rgba(34,227,240,0.6)]',
  success:
    'bg-gradient-to-br from-success-400 to-success-600 text-ink-950 shadow-glow-success hover:shadow-[0_0_32px_rgba(16,217,126,0.6)]',
  danger:
    'bg-gradient-to-br from-danger-400 to-danger-500 text-white shadow-glow-danger hover:shadow-[0_0_32px_rgba(255,61,110,0.6)]',
  ghost: 'glass-strong text-brand-100 hover:bg-white/10 hover:border-white/20',
};

const sizeMap: Record<NonNullable<GlowButtonProps['size']>, string> = {
  sm: 'px-4 py-2 text-xs',
  md: 'px-6 py-3 text-sm',
  lg: 'px-8 py-4 text-base',
};

export function GlowButton({
  children,
  variant = 'primary',
  size = 'md',
  fullWidth = false,
  className = '',
  disabled,
  ...rest
}: GlowButtonProps) {
  return (
    <motion.button
      whileHover={disabled ? undefined : { scale: 1.03 }}
      whileTap={disabled ? undefined : { scale: 0.97 }}
      transition={{ type: 'spring', stiffness: 400, damping: 17 }}
      disabled={disabled}
      className={`relative inline-flex items-center justify-center gap-2 rounded-2xl font-semibold tracking-tight transition-all duration-300 disabled:opacity-40 disabled:cursor-not-allowed disabled:shadow-none ${
        variantMap[variant]
      } ${sizeMap[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...(rest as React.ComponentProps<typeof motion.button>)}
    >
      {children}
    </motion.button>
  );
}
