import { NavLink, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Home, Sparkles, LayoutDashboard, Award, User } from 'lucide-react';

const tabs = [
  { to: '/dashboard', label: 'Home', icon: Home },
  { to: '/generate', label: 'Generate', icon: Sparkles },
  { to: '/analytics', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/certificate', label: 'Certificate', icon: Award },
  { to: '/profile', label: 'Profile', icon: User },
];

export function BottomNav() {
  const loc = useLocation();
  if (loc.pathname === '/') return null;

  return (
    <motion.nav
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.15 }}
      className="fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-md px-4 pb-4 sm:max-w-lg"
    >
      <div className="glass-strong flex items-center justify-between rounded-3xl px-2 py-2 shadow-glow">
        {tabs.map((tab) => {
          const active = loc.pathname === tab.to || (tab.to === '/analytics' && loc.pathname.startsWith('/analytics'));
          const Icon = tab.icon;
          return (
            <NavLink
              key={tab.to}
              to={tab.to}
              className="relative flex flex-1 flex-col items-center gap-0.5 py-1.5"
              aria-label={tab.label}
            >
              {active && (
                <motion.div
                  layoutId="tab-pill"
                  className="absolute inset-0 rounded-2xl bg-brand-gradient opacity-90 shadow-glow"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
              <Icon className={`relative h-5 w-5 transition-colors ${active ? 'text-white' : 'text-brand-200/60'}`} />
              <span className={`relative text-[9px] font-medium transition-colors ${active ? 'text-white' : 'text-brand-200/50'}`}>
                {tab.label}
              </span>
            </NavLink>
          );
        })}
      </div>
    </motion.nav>
  );
}
