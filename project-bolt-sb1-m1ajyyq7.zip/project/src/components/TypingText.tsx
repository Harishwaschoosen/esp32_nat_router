import { useEffect, useState } from 'react';

interface TypingTextProps {
  text: string;
  speed?: number;
  className?: string;
  onDone?: () => void;
  showCaret?: boolean;
  startDelay?: number;
}

export function TypingText({
  text,
  speed = 18,
  className = '',
  onDone,
  showCaret = true,
  startDelay = 0,
}: TypingTextProps) {
  const [shown, setShown] = useState('');
  const [started, setStarted] = useState(false);

  useEffect(() => {
    setShown('');
    setStarted(false);
    const startTimer = setTimeout(() => setStarted(true), startDelay);
    return () => clearTimeout(startTimer);
  }, [text, startDelay]);

  useEffect(() => {
    if (!started) return;
    if (shown.length >= text.length) {
      onDone?.();
      return;
    }
    const timer = setTimeout(() => {
      setShown(text.slice(0, shown.length + 1));
    }, speed);
    return () => clearTimeout(timer);
  }, [shown, started, text, speed, onDone]);

  return (
    <span className={className}>
      {shown}
      {showCaret && shown.length < text.length && (
        <span className="ml-0.5 inline-block h-[1.05em] w-[2px] translate-y-[2px] animate-caret-blink bg-aqua-400 align-middle" />
      )}
    </span>
  );
}
