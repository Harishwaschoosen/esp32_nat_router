import { AnimatePresence, motion } from 'framer-motion';
import { CheckCircle2, AlertTriangle, Info, XCircle, X } from 'lucide-react';
import { useApp } from '@/context/AppContext';

const variantMap = {
  info: { icon: Info, color: 'text-aqua-300', border: 'border-aqua-400/30' },
  success: { icon: CheckCircle2, color: 'text-success-400', border: 'border-success-500/30' },
  warning: { icon: AlertTriangle, color: 'text-warning-400', border: 'border-warning-500/30' },
  danger: { icon: XCircle, color: 'text-danger-400', border: 'border-danger-500/30' },
};

export function ToastHost() {
  const { toasts, dismissToast } = useApp();
  return (
    <div className="pointer-events-none fixed inset-x-0 top-4 z-[60] mx-auto flex w-full max-w-md flex-col items-center gap-2 px-4 sm:max-w-lg">
      <AnimatePresence>
        {toasts.map((t) => {
          const v = variantMap[t.variant];
          const Icon = v.icon;
          return (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: -24, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -16, scale: 0.95 }}
              className={`glass-strong pointer-events-auto flex w-full items-start gap-3 rounded-2xl border ${v.border} p-4 shadow-glow`}
            >
              <Icon className={`mt-0.5 h-5 w-5 shrink-0 ${v.color}`} />
              <div className="flex-1">
                <p className="text-sm font-semibold text-white">{t.title}</p>
                {t.message && <p className="mt-0.5 text-xs text-brand-200/70">{t.message}</p>}
              </div>
              <button onClick={() => dismissToast(t.id)} className="text-brand-200/50 transition hover:text-white" aria-label="Dismiss">
                <X className="h-4 w-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
