import { motion } from 'framer-motion';

interface FloatingBackgroundProps {
  variant?: 'default' | 'warm';
}

const blobs = [
  { top: '6%', left: '-8%', size: 340, color: 'rgba(91,102,255,0.30)', dur: 9 },
  { top: '32%', left: '68%', size: 280, color: 'rgba(139,92,246,0.24)', dur: 12 },
  { top: '68%', left: '8%', size: 240, color: 'rgba(124,140,255,0.22)', dur: 10 },
  { top: '52%', left: '44%', size: 200, color: 'rgba(34,227,240,0.14)', dur: 14 },
];

const warmBlobs = [
  { top: '10%', left: '-6%', size: 320, color: 'rgba(255,209,102,0.22)', dur: 10 },
  { top: '48%', left: '70%', size: 260, color: 'rgba(255,107,138,0.20)', dur: 12 },
  { top: '76%', left: '12%', size: 220, color: 'rgba(167,139,250,0.20)', dur: 13 },
];

export function FloatingBackground({ variant = 'default' }: FloatingBackgroundProps) {
  const list = variant === 'warm' ? warmBlobs : blobs;
  return (
    <div className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_-10%,rgba(91,102,255,0.20),transparent_55%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_85%_110%,rgba(139,92,246,0.14),transparent_50%)]" />
      {list.map((b, i) => (
        <motion.div
          key={`${b.top}-${b.left}`}
          className="absolute rounded-full blur-3xl"
          style={{ top: b.top, left: b.left, width: b.size, height: b.size, background: b.color }}
          animate={{ y: [0, -28, 0], x: [0, 16, 0], scale: [1, 1.07, 1] }}
          transition={{ duration: b.dur, repeat: Infinity, ease: 'easeInOut', delay: i * 0.6 }}
        />
      ))}
      <div
        className="absolute inset-0 opacity-[0.035]"
        style={{
          backgroundImage:
            'linear-gradient(rgba(255,255,255,0.6) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.6) 1px, transparent 1px)',
          backgroundSize: '46px 46px',
          maskImage: 'radial-gradient(circle at 50% 30%, black, transparent 70%)',
          WebkitMaskImage: 'radial-gradient(circle at 50% 30%, black, transparent 70%)',
        }}
      />
    </div>
  );
}
