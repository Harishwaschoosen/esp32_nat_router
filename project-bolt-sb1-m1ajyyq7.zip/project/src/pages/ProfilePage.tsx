import { motion } from 'framer-motion';
import { User, Award, Rocket, TrendingUp, Edit3, Settings, ArrowRight, Sparkles, Trophy, Star, Zap } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageLayout } from '@/components/PageLayout';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { AnimatedCounter } from '@/components/AnimatedCounter';
import { useApp } from '@/context/AppContext';
import { formatMoney, shortDate } from '@/lib/format';

export function ProfilePage() {
  const navigate = useNavigate();
  const { founder, setFounder, startups, deal, sound, notify } = useApp();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(founder.name);
  const [company, setCompany] = useState(founder.company || startups[0]?.name || '');

  const ceoLevel = deal
    ? 'Funded CEO'
    : startups.length > 3
    ? 'Serial Founder'
    : startups.length > 0
    ? 'Founder'
    : 'Aspiring Founder';

  const achievements = [
    { label: 'First Idea', unlocked: startups.length >= 1, icon: Sparkles },
    { label: 'Idea Machine', unlocked: startups.length >= 3, icon: Zap },
    { label: 'Fundraising', unlocked: !!deal, icon: TrendingUp },
    { label: 'Certified CEO', unlocked: !!deal, icon: Trophy },
    { label: 'Visionary', unlocked: startups.length >= 5, icon: Star },
  ];

  const stats = [
    { label: 'Ideas Generated', value: startups.length, icon: Rocket, color: 'text-brand-300' },
    { label: 'Funding Raised', value: deal ? formatMoney(deal.amount, true) : '$0', icon: TrendingUp, color: 'text-success-400', raw: true },
    { label: 'Certificates', value: deal ? 1 : 0, icon: Award, color: 'text-warning-400' },
  ];

  const save = () => {
    setFounder({ ...founder, name: name.trim() || 'Founder', company: company.trim() });
    setEditing(false);
    sound('success');
    notify({ title: 'Profile updated', message: 'Your founder profile has been saved.', variant: 'success' });
  };

  return (
    <PageLayout title="Profile" subtitle="Your founder journey" accent="brand" showSettings>
      {/* Founder card */}
      <GlassCard className="flex flex-col items-center p-6" glow="brand">
        <div className="relative">
          <div className="absolute -inset-2 rounded-full bg-brand-gradient opacity-30 blur-xl" />
          <div className="relative flex h-24 w-24 items-center justify-center rounded-full bg-brand-gradient text-3xl font-bold text-white shadow-glow">
            {(founder.name || 'F').slice(0, 1).toUpperCase()}
          </div>
          <div className="absolute -bottom-1 -right-1 flex h-7 w-7 items-center justify-center rounded-full border-2 border-ink-900 bg-success-500">
            <User className="h-3.5 w-3.5 text-ink-950" />
          </div>
        </div>
        <h2 className="mt-4 font-display text-xl font-bold text-white">{founder.name || 'Future CEO'}</h2>
        <p className="text-xs text-brand-200/60">{founder.company || startups[0]?.name || 'No company yet'}</p>
        <span className="chip mt-3 border-grape-400/40 bg-grape-500/15 text-grape-300">{ceoLevel}</span>
        <button
          onClick={() => { setEditing(!editing); sound('click'); }}
          className="mt-3 flex items-center gap-1.5 text-xs text-brand-200/60 transition hover:text-aqua-300"
        >
          <Edit3 className="h-3.5 w-3.5" /> {editing ? 'Cancel' : 'Edit profile'}
        </button>
      </GlassCard>

      {/* Edit form */}
      {editing && (
        <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} className="mt-3">
          <GlassCard className="space-y-3 p-5">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-brand-200/70">Founder Name</label>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="input-glow w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1.5 block text-xs font-medium text-brand-200/70">Company</label>
              <input
                value={company}
                onChange={(e) => setCompany(e.target.value)}
                className="input-glow w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white focus:outline-none"
              />
            </div>
            <GlowButton fullWidth onClick={save}>Save profile</GlowButton>
          </GlassCard>
        </motion.div>
      )}

      {/* Stats */}
      <div className="mt-4 grid grid-cols-3 gap-3">
        {stats.map((s, i) => {
          const Icon = s.icon;
          return (
            <GlassCard key={s.label} className="p-3 text-center" delay={i * 0.06}>
              <Icon className={`mx-auto h-4 w-4 ${s.color}`} />
              <p className="mt-1.5 font-display text-base font-bold text-white">
                {s.raw ? s.value : <AnimatedCounter value={Number(s.value)} />}
              </p>
              <p className="text-[10px] text-brand-200/60">{s.label}</p>
            </GlassCard>
          );
        })}
      </div>

      {/* Achievements */}
      <h2 className="mb-3 mt-6 flex items-center gap-2 text-sm font-semibold text-brand-200/80">
        <Award className="h-4 w-4 text-warning-400" /> Achievements
      </h2>
      <div className="grid grid-cols-5 gap-2">
        {achievements.map((a, i) => {
          const Icon = a.icon;
          return (
            <motion.div
              key={a.label}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.06 }}
              className={`flex flex-col items-center gap-1 rounded-2xl border p-2 text-center ${
                a.unlocked ? 'border-warning-500/30 bg-warning-500/10' : 'border-white/10 bg-white/5 opacity-40'
              }`}
            >
              <Icon className={`h-4 w-4 ${a.unlocked ? 'text-warning-400' : 'text-brand-200/40'}`} />
              <span className="text-[7px] leading-tight text-brand-200/70">{a.label}</span>
            </motion.div>
          );
        })}
      </div>

      {/* Recent startups */}
      {startups.length > 0 && (
        <>
          <h2 className="mb-3 mt-6 flex items-center gap-2 text-sm font-semibold text-brand-200/80">
            <Rocket className="h-4 w-4 text-brand-300" /> My Startups
          </h2>
          <div className="space-y-2">
            {startups.slice(0, 5).map((s) => (
              <div key={s.id} className="glass flex items-center gap-3 rounded-2xl p-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-brand-gradient text-xs font-bold text-white">
                  {s.name.slice(0, 2).toUpperCase()}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-white">{s.name}</p>
                  <p className="text-[11px] text-brand-200/60">{s.form.industry} · {shortDate(s.createdAt)}</p>
                </div>
                <span className="font-display text-sm font-bold text-gradient">{s.score}</span>
              </div>
            ))}
          </div>
        </>
      )}

      {/* CTAs */}
      <div className="mt-6 space-y-3">
        <GlowButton fullWidth size="lg" onClick={() => { sound('click'); navigate('/generate'); }}>
          <Sparkles className="h-5 w-5" /> Generate a new startup
        </GlowButton>
        <div className="grid grid-cols-2 gap-3">
          <GlowButton variant="ghost" onClick={() => { sound('click'); navigate('/settings'); }}>
            <Settings className="h-4 w-4" /> Settings
          </GlowButton>
          <GlowButton variant="aqua" onClick={() => { sound('click'); navigate('/about'); }}>
            About <ArrowRight className="h-4 w-4" />
          </GlowButton>
        </div>
      </div>
    </PageLayout>
  );
}
