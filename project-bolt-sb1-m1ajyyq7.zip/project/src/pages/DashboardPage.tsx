import { motion } from 'framer-motion';
import { Sparkles, Brain, Waves, Rocket, Award, TrendingUp, ArrowRight, Flame, Zap, Target } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PageLayout } from '@/components/PageLayout';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { AnimatedCounter } from '@/components/AnimatedCounter';
import { CircularProgress } from '@/components/CircularProgress';
import { EmptyState } from '@/components/EmptyState';
import { useApp } from '@/context/AppContext';
import { formatMoney, shortDate } from '@/lib/format';

const actions = [
  { to: '/generate', title: 'Generate Startup', desc: 'AI builds your venture', icon: Sparkles, glow: 'brand' as const, accent: 'text-brand-300', gradient: 'from-brand-500/20 to-grape-500/10' },
  { to: '/coach', title: 'AI Coach', desc: 'SWOT & startup score', icon: Brain, glow: 'aqua' as const, accent: 'text-aqua-300', gradient: 'from-aqua-500/20 to-brand-500/10' },
  { to: '/sharktank', title: 'Shark Tank', desc: 'Pitch AI investors', icon: Waves, glow: 'grape' as const, accent: 'text-grape-300', gradient: 'from-grape-500/20 to-brand-500/10' },
];

export function DashboardPage() {
  const navigate = useNavigate();
  const { startups, deal, founder, sound } = useApp();
  const name = founder.name || 'Future CEO';
  const avgScore = startups.length
    ? Math.round(startups.reduce((s, x) => s + x.score, 0) / startups.length)
    : 0;

  const go = (to: string) => {
    sound('click');
    navigate(to);
  };

  return (
    <PageLayout title={`Hello ${name}`} subtitle="Welcome back" back={false} accent="brand" showSettings>
      {/* Hero progress */}
      <GlassCard className="flex items-center justify-between p-5" glow="brand" hover elevated>
        <div>
          <div className="flex items-center gap-2 text-warning-400">
            <Flame className="h-4 w-4" />
            <span className="text-[11px] font-semibold uppercase tracking-wider">Founder Progress</span>
          </div>
          <p className="mt-1.5 font-display text-2xl font-bold text-white">
            <AnimatedCounter value={startups.length} /> startups
          </p>
          <p className="mt-1 text-xs text-brand-200/60">
            {deal ? `Funded: ${formatMoney(deal.amount, true)} raised` : 'Generate an idea to begin'}
          </p>
        </div>
        <CircularProgress value={avgScore || 0} max={100} size={88} stroke={8} sublabel="avg score" gradientFrom="#7c8cff" gradientTo="#8b5cf6" />
      </GlassCard>

      {/* Stats row */}
      <div className="mt-3 grid grid-cols-3 gap-3">
        <GlassCard className="p-3 text-center" delay={0.05} hover>
          <Rocket className="mx-auto h-4 w-4 text-brand-300" />
          <p className="mt-1.5 font-display text-lg font-bold text-white">
            <AnimatedCounter value={startups.length} />
          </p>
          <p className="text-[10px] text-brand-200/60">Ideas</p>
        </GlassCard>
        <GlassCard className="p-3 text-center" delay={0.1} hover>
          <TrendingUp className="mx-auto h-4 w-4 text-success-400" />
          <p className="mt-1.5 font-display text-lg font-bold text-white">
            {deal ? formatMoney(deal.amount, true) : '$0'}
          </p>
          <p className="text-[10px] text-brand-200/60">Funding</p>
        </GlassCard>
        <GlassCard className="p-3 text-center" delay={0.15} hover>
          <Award className="mx-auto h-4 w-4 text-warning-400" />
          <p className="mt-1.5 font-display text-lg font-bold text-white">
            <AnimatedCounter value={deal ? 1 : 0} />
          </p>
          <p className="text-[10px] text-brand-200/60">Certificates</p>
        </GlassCard>
      </div>

      {/* Top action cards */}
      <h2 className="mb-3 mt-6 flex items-center gap-2 text-sm font-semibold text-brand-200/80">
        <Zap className="h-4 w-4 text-aqua-300" /> Quick Actions
      </h2>
      <div className="space-y-3">
        {actions.map((a, i) => {
          const Icon = a.icon;
          return (
            <motion.button
              key={a.to}
              initial={{ opacity: 0, x: -16 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + i * 0.08 }}
              whileHover={{ y: -4 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => go(a.to)}
              className={`glass group relative flex w-full items-center gap-4 overflow-hidden rounded-3xl p-4 text-left transition-all duration-300 hover:shadow-card-hover`}
            >
              <div className={`absolute inset-0 bg-gradient-to-br ${a.gradient} opacity-0 transition-opacity duration-300 group-hover:opacity-100`} />
              <div className="relative flex h-12 w-12 items-center justify-center rounded-2xl bg-white/5">
                <Icon className={`h-6 w-6 ${a.accent}`} />
              </div>
              <div className="relative flex-1">
                <p className="font-display text-base font-bold text-white">{a.title}</p>
                <p className="text-xs text-brand-200/60">{a.desc}</p>
              </div>
              <ArrowRight className="relative h-5 w-5 text-brand-200/30 transition-all group-hover:translate-x-1 group-hover:text-white" />
            </motion.button>
          );
        })}
      </div>

      {/* Recent startups */}
      <h2 className="mb-3 mt-6 flex items-center gap-2 text-sm font-semibold text-brand-200/80">
        <Target className="h-4 w-4 text-grape-300" /> Recent Startups
      </h2>
      {startups.length === 0 ? (
        <EmptyState
          icon={<Sparkles className="h-7 w-7" />}
          title="No startups yet"
          message="Generate your first startup in under 60 seconds."
          action={<GlowButton onClick={() => go('/generate')}>Generate now</GlowButton>}
        />
      ) : (
        <div className="space-y-3">
          {startups.slice(0, 3).map((s, i) => (
            <motion.button
              key={s.id}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.07 }}
              whileHover={{ y: -3 }}
              onClick={() => go('/coach')}
              className="glass flex w-full items-center gap-3 rounded-2xl p-4 text-left transition hover:bg-white/10"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-brand-gradient-hero text-sm font-bold text-white shadow-glow">
                {s.name.slice(0, 2).toUpperCase()}
              </div>
              <div className="flex-1">
                <p className="text-sm font-semibold text-white">{s.name}</p>
                <p className="text-[11px] text-brand-200/60">{s.form.industry} · {shortDate(s.createdAt)}</p>
              </div>
              <div className="flex flex-col items-end">
                <span className="font-display text-base font-bold text-gradient">{s.score}</span>
                <span className="text-[9px] text-brand-200/50">score</span>
              </div>
            </motion.button>
          ))}
        </div>
      )}

      {/* Primary CTA */}
      <div className="mt-6">
        <GlowButton fullWidth size="lg" onClick={() => go('/generate')}>
          <Sparkles className="h-5 w-5" /> Generate my next startup
        </GlowButton>
        {deal && (
          <button
            onClick={() => go('/certificate')}
            className="mt-3 flex w-full items-center justify-center gap-2 text-xs text-brand-200/60 transition hover:text-warning-400"
          >
            <Award className="h-4 w-4" /> View your CEO Certificate
          </button>
        )}
      </div>
    </PageLayout>
  );
}
