import { motion } from 'framer-motion';
import { Rocket, Sparkles, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/context/AppContext';

export function SplashPage() {
  const navigate = useNavigate();
  const { sound } = useApp();

  const start = () => {
    sound('click');
    navigate('/dashboard');
  };

  return (
    <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col items-center justify-center px-6 sm:max-w-lg">
      {/* Logo mark */}
      <motion.div
        initial={{ scale: 0.5, opacity: 0, rotate: -15 }}
        animate={{ scale: 1, opacity: 1, rotate: 0 }}
        transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
        className="relative"
      >
        <motion.div
          animate={{ scale: [1, 1.06, 1] }}
          transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -inset-8 rounded-[3rem] bg-brand-gradient-hero opacity-40 blur-3xl"
        />
        <div className="relative flex h-28 w-28 items-center justify-center rounded-[2rem] bg-brand-gradient-hero shadow-glow-lg">
          <Rocket className="h-12 w-12 text-white" />
          <div className="absolute inset-0 rounded-[2rem] border border-white/20" />
        </div>
        <motion.div
          initial={{ opacity: 0, scale: 0.5 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.7, type: 'spring', stiffness: 200 }}
          className="absolute -right-3 -top-3 flex h-10 w-10 items-center justify-center rounded-2xl border border-white/20 bg-ink-900/90 backdrop-blur shadow-glow"
        >
          <Sparkles className="h-4 w-4 text-aqua-300" />
        </motion.div>
      </motion.div>

      {/* Wordmark — X is a bold gradient so it always reads */}
      <motion.h1
        initial={{ opacity: 0, y: 20, letterSpacing: '0.3em' }}
        animate={{ opacity: 1, y: 0, letterSpacing: '0em' }}
        transition={{ delay: 0.5, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="mt-10 font-display text-5xl font-bold tracking-tight"
      >
        <span className="text-gradient">Founder</span>
        <span className="text-gradient-2 text-shadow-glow">X</span>
        <span className="ml-2 text-gradient-warm">AI</span>
      </motion.h1>

      {/* Pillars */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9 }}
        className="mt-5 flex items-center gap-2.5 text-[11px] font-semibold uppercase tracking-[0.22em]"
      >
        <span className="text-brand-200">Build</span>
        <span className="text-brand-200/30">·</span>
        <span className="text-grape-300">Validate</span>
        <span className="text-brand-200/30">·</span>
        <span className="text-aqua-300">Pitch</span>
        <span className="text-brand-200/30">·</span>
        <span className="text-gradient-warm">Become a CEO</span>
      </motion.div>

      {/* Tagline */}
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.1 }}
        className="mt-6 max-w-[16rem] text-center text-sm leading-relaxed text-brand-200/65"
      >
        Create your startup in less than 60 seconds.
      </motion.p>

      {/* CTA */}
      <motion.button
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.3, duration: 0.6 }}
        whileHover={{ scale: 1.04 }}
        whileTap={{ scale: 0.96 }}
        onClick={start}
        className="group mt-10 inline-flex items-center gap-2.5 rounded-2xl bg-brand-gradient-hero px-9 py-4 text-sm font-semibold text-white shadow-glow-lg animate-pulse-glow"
      >
        Start Your Journey
        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
      </motion.button>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.7 }}
        className="absolute bottom-8 text-[10px] uppercase tracking-[0.3em] text-brand-200/35"
      >
        Powered by FounderX Intelligence
      </motion.p>
    </div>
  );
}
