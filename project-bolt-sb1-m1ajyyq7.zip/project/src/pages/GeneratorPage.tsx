import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, RefreshCw, ArrowRight, Rocket, Target, Users, DollarSign, Shield, Lightbulb, TrendingUp, AlertTriangle, Building2, Megaphone, Gauge, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageLayout } from '@/components/PageLayout';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { CircularProgress } from '@/components/CircularProgress';
import { TypingText } from '@/components/TypingText';
import { useApp } from '@/context/AppContext';
import { generateStartup, industries, experienceLevels, countryList } from '@/lib/generator';
import { formatMoney } from '@/lib/format';
import type { ExperienceLevel, Startup, StartupForm } from '@/types';

const initialForm: StartupForm = {
  founderName: '',
  idea: '',
  industry: 'AI',
  budget: 25000,
  country: 'USA',
  targetCustomers: '',
  experience: 'Beginner',
};

const fields: { key: string; label: string; placeholder: string; icon: typeof Target; type?: string }[] = [
  { key: 'founderName', label: 'Founder Name', placeholder: 'e.g. Alex Rivera', icon: Users },
  { key: 'idea', label: 'Startup Idea', placeholder: 'e.g. AI meal planner for busy professionals', icon: Lightbulb },
  { key: 'targetCustomers', label: 'Target Customers', placeholder: 'e.g. Working parents aged 30-45', icon: Target },
];

function fieldIcon(key: keyof Startup) {
  const map: Record<string, typeof Target> = {
    problem: Target,
    solution: Lightbulb,
    targetCustomers: Users,
    businessModel: DollarSign,
    marketingPlan: Megaphone,
  };
  return map[key] ?? Sparkles;
}

export function GeneratorPage() {
  const navigate = useNavigate();
  const { saveStartup, setCurrentStartup, founder, setFounder, sound, notify } = useApp();
  const [form, setForm] = useState<StartupForm>({
    ...initialForm,
    founderName: founder.name || '',
  });
  const [loading, setLoading] = useState(false);
  const [startup, setStartup] = useState<Startup | null>(null);
  const [typedName, setTypedName] = useState(false);
  const [saved, setSaved] = useState(false);

  const update = (key: keyof StartupForm, value: string | number) => {
    setForm((f) => ({ ...f, [key]: value }));
    if (key === 'founderName' && typeof value === 'string') setFounder({ ...founder, name: value });
  };

  const valid = form.founderName.trim() && form.idea.trim();

  const generate = () => {
    if (!valid) {
      notify({ title: 'Almost there', message: 'Add your name and a startup idea first.', variant: 'warning' });
      return;
    }
    sound('generate');
    setLoading(true);
    setStartup(null);
    setTypedName(false);
    setSaved(false);
    setTimeout(() => {
      const s = generateStartup(form);
      setStartup(s);
      setCurrentStartup(s);
      saveStartup(s);
      setSaved(true);
      setLoading(false);
      notify({ title: 'Startup generated', message: `${s.name} is ready to review.`, variant: 'success' });
    }, 2100);
  };

  return (
    <PageLayout title="Startup Generator" subtitle="Built in under 60 seconds" accent="brand">
      <AnimatePresence mode="wait">
        {!startup && !loading && (
          <motion.div key="form" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <GlassCard className="p-5" glow="brand">
              <div className="space-y-4">
                {fields.map((f) => {
                  const Icon = f.icon;
                  return (
                    <div key={f.key}>
                      <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-brand-200/70">
                        <Icon className="h-3.5 w-3.5 text-aqua-300" /> {f.label}
                      </label>
                      <input
                        value={form[f.key as keyof StartupForm] as string}
                        onChange={(e) => update(f.key as keyof StartupForm, e.target.value)}
                        placeholder={f.placeholder}
                        className="input-glow w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-white placeholder:text-brand-200/40 focus:outline-none"
                      />
                    </div>
                  );
                })}

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-brand-200/70">
                      <Building2 className="h-3.5 w-3.5 text-grape-300" /> Industry
                    </label>
                    <select
                      value={form.industry}
                      onChange={(e) => update('industry', e.target.value)}
                      className="input-glow w-full rounded-2xl border border-white/10 bg-white/5 px-3 py-3 text-sm text-white focus:outline-none"
                    >
                      {industries.map((i) => (
                        <option key={i} value={i} className="bg-ink-900">{i}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-brand-200/70">
                      <Target className="h-3.5 w-3.5 text-aqua-300" /> Country
                    </label>
                    <select
                      value={form.country}
                      onChange={(e) => update('country', e.target.value)}
                      className="input-glow w-full rounded-2xl border border-white/10 bg-white/5 px-3 py-3 text-sm text-white focus:outline-none"
                    >
                      {countryList.map((c) => (
                        <option key={c} value={c} className="bg-ink-900">{c}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <div className="mb-1.5 flex items-center justify-between text-xs font-medium text-brand-200/70">
                    <span className="flex items-center gap-1.5"><DollarSign className="h-3.5 w-3.5 text-success-400" /> Budget</span>
                    <span className="font-display font-bold text-white">{formatMoney(form.budget)}</span>
                  </div>
                  <input
                    type="range" min={1000} max={250000} step={1000}
                    value={form.budget}
                    onChange={(e) => update('budget', Number(e.target.value))}
                    className="w-full accent-brand-500"
                  />
                </div>

                <div>
                  <label className="mb-1.5 flex items-center gap-1.5 text-xs font-medium text-brand-200/70">
                    <Gauge className="h-3.5 w-3.5 text-warning-400" /> Experience Level
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {experienceLevels.map((lvl) => (
                      <button
                        key={lvl}
                        onClick={() => update('experience', lvl as ExperienceLevel)}
                        className={`rounded-2xl border px-3 py-2.5 text-xs font-medium transition ${
                          form.experience === lvl
                            ? 'border-brand-400/60 bg-brand-500/20 text-white shadow-glow'
                            : 'border-white/10 bg-white/5 text-brand-200/70 hover:bg-white/10'
                        }`}
                      >
                        {lvl}
                      </button>
                    ))}
                  </div>
                </div>

                <GlowButton fullWidth size="lg" onClick={generate} disabled={!valid}>
                  <Sparkles className="h-5 w-5" /> Generate Startup
                </GlowButton>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {loading && (
          <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center justify-center py-16">
            <div className="relative">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 1.4, repeat: Infinity, ease: 'linear' }}
                className="flex h-20 w-20 items-center justify-center rounded-3xl bg-brand-gradient shadow-glow"
              >
                <Sparkles className="h-9 w-9 text-white" />
              </motion.div>
              <div className="absolute -inset-3 rounded-[2rem] bg-brand-gradient opacity-30 blur-2xl animate-pulse-glow" />
            </div>
            <p className="mt-6 font-display text-lg font-bold text-white">AI is building your startup...</p>
            <div className="mt-3 flex gap-1.5">
              {[0, 1, 2].map((i) => (
                <motion.span
                  key={i}
                  className="h-2 w-2 rounded-full bg-aqua-400"
                  animate={{ opacity: [0.3, 1, 0.3], y: [0, -4, 0] }}
                  transition={{ duration: 1, repeat: Infinity, delay: i * 0.18 }}
                />
              ))}
            </div>
            <p className="mt-4 text-center text-xs text-brand-200/50">Analyzing market · Crafting model · Scoring viability</p>
          </motion.div>
        )}

        {startup && !loading && (
          <motion.div key="result" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <GlassCard className="p-5" glow="brand">
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <span className="chip mb-3">{startup.form.industry}</span>
                  <h2 className="font-display text-2xl font-bold text-white">
                    <TypingText text={startup.name} speed={70} onDone={() => setTypedName(true)} showCaret={false} />
                  </h2>
                  {typedName && (
                    <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-1 text-sm text-brand-200/80">
                      <TypingText text={startup.solution.slice(0, 90) + '...'} speed={14} />
                    </motion.p>
                  )}
                </div>
                <CircularProgress value={startup.score} max={100} size={92} stroke={9} sublabel="score" />
              </div>
            </GlassCard>

            {typedName && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-3 space-y-3">
                {/* Problem & Solution */}
                {(['problem', 'solution', 'targetCustomers', 'businessModel', 'marketingPlan'] as const).map((k, idx) => {
                  const Icon = fieldIcon(k);
                  const labels: Record<string, string> = {
                    problem: 'Problem', solution: 'Solution', targetCustomers: 'Target Customers',
                    businessModel: 'Business Model', marketingPlan: 'Marketing Plan',
                  };
                  return (
                    <motion.div key={k} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: idx * 0.1 }}>
                      <GlassCard className="p-4">
                        <div className="flex items-center gap-2 text-brand-200/70">
                          <Icon className="h-4 w-4 text-aqua-300" />
                          <span className="text-[11px] font-semibold uppercase tracking-wider">{labels[k]}</span>
                        </div>
                        <p className="mt-2 text-sm leading-relaxed text-brand-100/90">{startup[k]}</p>
                      </GlassCard>
                    </motion.div>
                  );
                })}

                {/* Revenue streams */}
                <GlassCard className="p-4">
                  <div className="flex items-center gap-2 text-brand-200/70">
                    <DollarSign className="h-4 w-4 text-success-400" />
                    <span className="text-[11px] font-semibold uppercase tracking-wider">Revenue Streams</span>
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {startup.revenueStreams.map((r) => (
                      <span key={r} className="chip">{r}</span>
                    ))}
                  </div>
                </GlassCard>

                {/* Financials grid */}
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: 'Startup Cost', value: formatMoney(startup.startupCost), icon: DollarSign, color: 'text-warning-400' },
                    { label: 'Monthly Revenue', value: formatMoney(startup.monthlyRevenue), icon: TrendingUp, color: 'text-success-400' },
                    { label: 'Team Size', value: `${startup.teamSize} people`, icon: Users, color: 'text-aqua-300' },
                    { label: 'Funding Required', value: formatMoney(startup.fundingRequired, true), icon: Rocket, color: 'text-grape-300' },
                    { label: 'Difficulty', value: startup.difficulty, icon: AlertTriangle, color: 'text-danger-400' },
                    { label: 'Success Probability', value: `${startup.successProbability}%`, icon: Gauge, color: 'text-brand-300' },
                  ].map((m) => {
                    const Icon = m.icon;
                    return (
                      <GlassCard key={m.label} className="p-4">
                        <Icon className={`h-4 w-4 ${m.color}`} />
                        <p className="mt-2 font-display text-base font-bold text-white">{m.value}</p>
                        <p className="text-[10px] text-brand-200/60">{m.label}</p>
                      </GlassCard>
                    );
                  })}
                </div>

                {saved && (
                  <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-center justify-center gap-2 text-xs text-success-400">
                    <CheckCircle2 className="h-4 w-4" /> Startup saved to your profile
                  </motion.div>
                )}

                <div className="grid grid-cols-2 gap-3 pt-1">
                  <GlowButton variant="ghost" onClick={generate}>
                    <RefreshCw className="h-4 w-4" /> Regenerate
                  </GlowButton>
                  <GlowButton variant="aqua" onClick={() => { sound('click'); navigate('/coach'); }}>
                    Continue <ArrowRight className="h-4 w-4" />
                  </GlowButton>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </PageLayout>
  );
}
