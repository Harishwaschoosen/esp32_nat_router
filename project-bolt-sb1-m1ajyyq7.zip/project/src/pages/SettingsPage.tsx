import { motion } from 'framer-motion';
import { Moon, Sun, Volume2, VolumeX, Bell, BellOff, Trash2, ArrowLeft, Info } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PageLayout } from '@/components/PageLayout';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { useApp } from '@/context/AppContext';

export function SettingsPage() {
  const navigate = useNavigate();
  const { settings, setSettings, hardReset, sound, notify } = useApp();

  const toggle = (key: 'darkMode' | 'sound' | 'notifications') => {
    setSettings({ [key]: !settings[key] });
    sound('toggle');
  };

  const rows = [
    { key: 'darkMode' as const, label: 'Dark Mode', desc: 'Premium dark theme', iconOn: Moon, iconOff: Sun, value: settings.darkMode },
    { key: 'sound' as const, label: 'Sound Effects', desc: 'Click and success tones', iconOn: Volume2, iconOff: VolumeX, value: settings.sound },
    { key: 'notifications' as const, label: 'Notifications', desc: 'Toasts on key actions', iconOn: Bell, iconOff: BellOff, value: settings.notifications },
  ];

  return (
    <PageLayout title="Settings" subtitle="Customize your experience" accent="brand">
      <div className="space-y-3">
        {rows.map((r, i) => {
          const Icon = r.value ? r.iconOn : r.iconOff;
          return (
            <motion.div key={r.key} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.07 }}>
              <GlassCard className="flex items-center gap-4 p-4">
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/5">
                  <Icon className={`h-5 w-5 ${r.value ? 'text-aqua-300' : 'text-brand-200/50'}`} />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-white">{r.label}</p>
                  <p className="text-[11px] text-brand-200/60">{r.desc}</p>
                </div>
                <button
                  onClick={() => toggle(r.key)}
                  className={`relative h-7 w-12 rounded-full transition-colors ${r.value ? 'bg-brand-gradient' : 'bg-white/10'}`}
                  aria-label={`Toggle ${r.label}`}
                >
                  <motion.span
                    layout
                    transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                    className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow ${r.value ? 'left-6' : 'left-1'}`}
                  />
                </button>
              </GlassCard>
            </motion.div>
          );
        })}
      </div>

      {/* Data */}
      <h2 className="mb-3 mt-6 text-sm font-semibold text-brand-200/80">Data</h2>
      <GlassCard className="p-5">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-danger-500/15">
            <Trash2 className="h-5 w-5 text-danger-400" />
          </div>
          <div className="flex-1">
            <p className="text-sm font-semibold text-white">Reset all data</p>
            <p className="text-[11px] text-brand-200/60">Clears startups, deals, and profile</p>
          </div>
        </div>
        <GlowButton
          fullWidth
          variant="danger"
          className="mt-4"
          onClick={() => {
            hardReset();
            setTimeout(() => navigate('/dashboard'), 300);
          }}
        >
          <Trash2 className="h-4 w-4" /> Clear everything
        </GlowButton>
      </GlassCard>

      {/* About link */}
      <GlassCard className="mt-3 flex items-center gap-4 p-4">
        <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/5">
          <Info className="h-5 w-5 text-grape-300" />
        </div>
        <div className="flex-1">
          <p className="text-sm font-semibold text-white">About FounderX AI</p>
          <p className="text-[11px] text-brand-200/60">Learn about the mission</p>
        </div>
        <GlowButton size="sm" variant="ghost" onClick={() => { sound('click'); navigate('/about'); }}>
          Open
        </GlowButton>
      </GlassCard>

      <button
        onClick={() => { sound('click'); navigate('/dashboard'); }}
        className="mt-6 flex w-full items-center justify-center gap-2 text-xs text-brand-200/60 transition hover:text-white"
      >
        <ArrowLeft className="h-4 w-4" /> Back to Home
      </button>

      <p className="mt-4 text-center text-[10px] text-brand-200/40">FounderX AI · v1.0.0</p>
    </PageLayout>
  );
}
