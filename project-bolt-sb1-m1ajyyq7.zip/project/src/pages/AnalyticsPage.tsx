import { motion } from 'framer-motion';
import {
  ResponsiveContainer, LineChart as RLineChart, Line, BarChart as RBarChart, Bar,
  PieChart as RPieChart, Pie, Cell, XAxis, YAxis, Tooltip, CartesianGrid, Legend,
} from 'recharts';
import { TrendingUp, DollarSign, Users, Activity, Wallet, PiggyBank, ArrowRight, Sparkles, BarChart3 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageLayout } from '@/components/PageLayout';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { AnimatedCounter } from '@/components/AnimatedCounter';
import { StatSkeleton, ChartSkeleton } from '@/components/Skeletons';
import { EmptyState } from '@/components/EmptyState';
import { useApp } from '@/context/AppContext';
import { buildAnalytics, growthPie } from '@/lib/analytics';
import { formatMoney } from '@/lib/format';

const PIE_COLORS = ['#7c8cff', '#8b5cf6', '#22e3f0', '#34f5b0'];

export function AnalyticsPage() {
  const navigate = useNavigate();
  const { currentStartup, startups, deal, sound } = useApp();
  const startup = currentStartup ?? startups[0] ?? null;
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoaded(true), 600);
    return () => clearTimeout(t);
  }, []);

  if (!startup) {
    return (
      <PageLayout title="Analytics" subtitle="Your startup at a glance" accent="aqua">
        <EmptyState
          icon={<BarChart3 className="h-7 w-7" />}
          title="No data to chart yet"
          message="Generate a startup to unlock revenue, profit, and growth analytics."
          action={<GlowButton onClick={() => { sound('click'); navigate('/generate'); }}>Generate a startup</GlowButton>}
        />
      </PageLayout>
    );
  }

  const { series, totals } = buildAnalytics(startup);
  const pieData = growthPie(series);

  const kpis = [
    { label: 'Revenue', value: totals.revenue, prefix: '$', icon: DollarSign, color: 'text-success-400', compact: true },
    { label: 'Funding', value: deal?.amount ?? startup.fundingRequired, prefix: '$', icon: Wallet, color: 'text-grape-300', compact: true },
    { label: 'Customers', value: totals.customers, icon: Users, color: 'text-aqua-300', compact: false },
    { label: 'Growth', value: totals.growth, suffix: '%', icon: TrendingUp, color: 'text-success-400', compact: false },
    { label: 'Expenses', value: totals.expenses, prefix: '$', icon: Activity, color: 'text-danger-400', compact: true },
    { label: 'Profit', value: totals.profit, prefix: '$', icon: PiggyBank, color: 'text-success-400', compact: true },
  ];

  return (
    <PageLayout title="Analytics" subtitle={startup.name} accent="aqua">
      {/* KPI grid */}
      <div className="grid grid-cols-2 gap-3">
        {loaded
          ? kpis.map((k, i) => {
              const Icon = k.icon;
              return (
                <GlassCard key={k.label} className="p-4" delay={i * 0.05} hover glow="aqua">
                  <div className="flex items-center justify-between">
                    <Icon className={`h-4 w-4 ${k.color}`} />
                  </div>
                  <p className="mt-2 font-display text-xl font-bold text-white">
                    <AnimatedCounter value={k.value} prefix={k.prefix} suffix={k.suffix} />
                  </p>
                  <p className="text-[11px] text-brand-200/60">{k.label}</p>
                </GlassCard>
              );
            })
          : Array.from({ length: 6 }).map((_, i) => <StatSkeleton key={i} />)}
      </div>

      {/* Revenue line chart */}
      <div className="mt-4">
        {loaded ? (
          <GlassCard className="p-5" delay={0.2} glow="brand">
            <div className="mb-1 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-success-400" />
                <span className="text-sm font-semibold text-white">Revenue (12 months)</span>
              </div>
              <span className="chip text-success-400">+{totals.growth}%</span>
            </div>
            <p className="text-[11px] text-brand-200/50">Monthly recurring revenue</p>
            <div className="mt-3 h-48">
              <ResponsiveContainer width="100%" height="100%">
                <RLineChart data={series} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
                  <defs>
                    <linearGradient id="revGrad" x1="0" y1="0" x2="1" y2="0">
                      <stop offset="0%" stopColor="#7c8cff" />
                      <stop offset="100%" stopColor="#22e3f0" />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="month" tick={{ fill: '#a5b2ff', fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#a5b2ff', fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ background: '#0c0f22', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, fontSize: 12 }}
                    labelStyle={{ color: '#a5b2ff' }}
                  />
                  <Line type="monotone" dataKey="revenue" stroke="url(#revGrad)" strokeWidth={3} dot={{ r: 3, fill: '#0a0c1b', stroke: '#7c8cff' }} activeDot={{ r: 5 }} />
                </RLineChart>
              </ResponsiveContainer>
            </div>
          </GlassCard>
        ) : (
          <ChartSkeleton />
        )}
      </div>

      {/* Profit bar chart */}
      <div className="mt-4">
        {loaded ? (
          <GlassCard className="p-5" delay={0.3} glow="grape">
            <div className="mb-1 flex items-center gap-2">
              <PiggyBank className="h-4 w-4 text-grape-300" />
              <span className="text-sm font-semibold text-white">Profit by Month</span>
            </div>
            <p className="text-[11px] text-brand-200/50">Revenue minus expenses</p>
            <div className="mt-3 h-48">
              <ResponsiveContainer width="100%" height="100%">
                <RBarChart data={series} margin={{ top: 8, right: 8, bottom: 0, left: -20 }}>
                  <defs>
                    <linearGradient id="profitGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#8b5cf6" />
                      <stop offset="100%" stopColor="#5b66ff" />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                  <XAxis dataKey="month" tick={{ fill: '#a5b2ff', fontSize: 10 }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#a5b2ff', fontSize: 10 }} axisLine={false} tickLine={false} />
                  <Tooltip
                    contentStyle={{ background: '#0c0f22', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, fontSize: 12 }}
                    cursor={{ fill: 'rgba(255,255,255,0.04)' }}
                  />
                  <Bar dataKey="profit" fill="url(#profitGrad)" radius={[6, 6, 0, 0]} />
                </RBarChart>
              </ResponsiveContainer>
            </div>
          </GlassCard>
        ) : (
          <ChartSkeleton />
        )}
      </div>

      {/* Growth pie chart */}
      <div className="mt-4">
        {loaded ? (
          <GlassCard className="flex items-center gap-5 p-5" delay={0.4} glow="aqua">
            <div className="h-40 w-40 shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <RPieChart>
                  <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={42} outerRadius={70} paddingAngle={3}>
                    {pieData.map((_, i) => (
                      <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: '#0c0f22', border: '1px solid rgba(255,255,255,0.1)', borderRadius: 12, fontSize: 12 }}
                  />
                  <Legend formatter={(v) => <span style={{ color: '#a5b2ff', fontSize: 10 }}>{v}</span>} />
                </RPieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex-1">
              <p className="text-sm font-semibold text-white">Customer Growth</p>
              <p className="text-[11px] text-brand-200/50">By quarter</p>
              <div className="mt-3 space-y-2">
                {pieData.map((s, i) => (
                  <div key={s.name} className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-2 text-brand-200/70">
                      <span className="h-2.5 w-2.5 rounded-full" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
                      {s.name}
                    </span>
                    <span className="font-semibold text-white">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </GlassCard>
        ) : (
          <ChartSkeleton />
        )}
      </div>

      {loaded && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="mt-5">
          <GlowButton fullWidth size="lg" variant="aqua" onClick={() => { sound('click'); navigate('/coach'); }}>
            <Sparkles className="h-5 w-5" /> Ask AI Coach for next steps <ArrowRight className="h-4 w-4" />
          </GlowButton>
        </motion.div>
      )}
    </PageLayout>
  );
}
