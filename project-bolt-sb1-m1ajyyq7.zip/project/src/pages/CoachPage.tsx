import { motion, AnimatePresence } from 'framer-motion';
import { Brain, ArrowRight, Zap, TrendingUp, Target, Shield, AlertTriangle, DollarSign, Megaphone, Rocket, Trophy } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PageLayout } from '@/components/PageLayout';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { CircularProgress } from '@/components/CircularProgress';
import { EmptyState } from '@/components/EmptyState';
import { useApp } from '@/context/AppContext';
import { formatMoney } from '@/lib/format';

const swotConfig = [
  { key: 'strengths', label: 'Strengths', icon: TrendingUp, color: 'text-success-400', border: 'border-success-500/30' },
  { key: 'weaknesses', label: 'Weaknesses', icon: AlertTriangle, color: 'text-warning-400', border: 'border-warning-500/30' },
  { key: 'opportunities', label: 'Opportunities', icon: Zap, color: 'text-aqua-300', border: 'border-aqua-400/30' },
  { key: 'threats', label: 'Threats', icon: Shield, color: 'text-danger-400', border: 'border-danger-500/30' },
] as const;

export function CoachPage() {
  const navigate = useNavigate();
  const { currentStartup, startups, sound } = useApp();
  const startup = currentStartup ?? startups[0] ?? null;

  if (!startup) {
    return (
      <PageLayout title="AI Coach" subtitle="SWOT & startup score" accent="aqua">
        <EmptyState
          icon={<Brain className="h-7 w-7" />}
          title="No startup to analyze"
          message="Generate a startup first, and the AI Coach will run a full SWOT analysis."
          action={<GlowButton onClick={() => { sound('click'); navigate('/generate'); }}>Generate a startup</GlowButton>}
        />
      </PageLayout>
    );
  }

  const isUnicorn = startup.score >= 90;

  const metrics = [
    { label: 'Startup Cost', value: formatMoney(startup.metrics.startupCost), icon: DollarSign, color: 'text-warning-400' },
    { label: 'Market Size', value: startup.metrics.marketSize, icon: Target, color: 'text-aqua-300' },
    { label: 'Competition', value: startup.metrics.competition.split(' — ')[0], icon: Shield, color: 'text-grape-300' },
    { label: 'Risk Level', value: startup.metrics.riskLevel, icon: AlertTriangle, color: 'text-danger-400' },
    { label: 'Funding Advice', value: 'Tap to read', icon: Rocket, color: 'text-success-400', full: true, detail: startup.metrics.fundingAdvice },
    { label: 'Break Even', value: startup.metrics.breakEvenTime, icon: TrendingUp, color: 'text-brand-300' },
  ];

  return (
    <PageLayout title="AI Coach" subtitle={`Analyzing ${startup.name}`} accent="aqua">
      {/* Score + unicorn badge */}
      <GlassCard className="flex flex-col items-center p-6" glow="aqua">
        <div className="mb-1 flex items-center gap-2 text-brand-200/70">
          <Brain className="h-4 w-4 text-aqua-300" />
          <span className="text-xs uppercase tracking-wider">Startup Score</span>
        </div>
        <CircularProgress
          value={startup.score}
          max={100}
          size={150}
          stroke={14}
          sublabel="out of 100"
          gradientFrom="#7c8cff"
          gradientTo="#8b5cf6"
        />
        <AnimatePresence>
          {isUnicorn && (
            <motion.div
              initial={{ opacity: 0, scale: 0.6 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-4 flex items-center gap-2 rounded-2xl border border-warning-500/30 bg-warning-500/10 px-4 py-2"
            >
              <Trophy className="h-5 w-5 text-warning-400" />
              <span className="font-display text-sm font-bold text-gradient-warm">Potential Unicorn</span>
            </motion.div>
          )}
        </AnimatePresence>
      </GlassCard>

      {/* SWOT */}
      <h2 className="mb-3 mt-6 flex items-center gap-2 text-sm font-semibold text-brand-200/80">
        <Shield className="h-4 w-4 text-grape-300" /> SWOT Analysis
      </h2>
      <div className="grid grid-cols-1 gap-3">
        {swotConfig.map((s, i) => {
          const Icon = s.icon;
          const items = startup.swot[s.key];
          return (
            <motion.div key={s.key} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.08 }}>
              <GlassCard className={`p-4 ${s.border}`}>
                <div className={`flex items-center gap-2 ${s.color}`}>
                  <Icon className="h-4 w-4" />
                  <span className="text-xs font-semibold uppercase tracking-wider">{s.label}</span>
                </div>
                <ul className="mt-3 space-y-2">
                  {items.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm text-brand-100/90">
                      <span className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${s.color.replace('text-', 'bg-')}`} />
                      {item}
                    </li>
                  ))}
                </ul>
              </GlassCard>
            </motion.div>
          );
        })}
      </div>

      {/* Metrics */}
      <h2 className="mb-3 mt-6 flex items-center gap-2 text-sm font-semibold text-brand-200/80">
        <Megaphone className="h-4 w-4 text-aqua-300" /> Key Metrics
      </h2>
      <div className="grid grid-cols-2 gap-3">
        {metrics.map((m, i) => {
          const Icon = m.icon;
          return (
            <motion.div key={m.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }} className={m.full ? 'col-span-2' : ''}>
              <GlassCard className="h-full p-4" hover glow="aqua">
                <Icon className={`h-4 w-4 ${m.color}`} />
                <p className="mt-2 font-display text-base font-bold text-white">{m.value}</p>
                <p className="text-[10px] text-brand-200/60">{m.label}</p>
                {m.detail && <p className="mt-2 text-xs leading-relaxed text-brand-200/70">{m.detail}</p>}
              </GlassCard>
            </motion.div>
          );
        })}
      </div>

      {/* CTA */}
      <div className="mt-6">
        <GlowButton fullWidth size="lg" variant="grape" onClick={() => { sound('click'); navigate('/sharktank'); }}>
          <Rocket className="h-5 w-5" /> Pitch Investors <ArrowRight className="h-4 w-4" />
        </GlowButton>
        <button
          onClick={() => { sound('click'); navigate('/analytics'); }}
          className="mt-3 flex w-full items-center justify-center gap-2 text-xs text-brand-200/60 transition hover:text-aqua-300"
        >
          <TrendingUp className="h-4 w-4" /> Open analytics dashboard
        </button>
      </div>
    </PageLayout>
  );
}
