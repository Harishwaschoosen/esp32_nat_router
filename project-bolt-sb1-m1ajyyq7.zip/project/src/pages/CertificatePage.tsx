import { motion, AnimatePresence } from 'framer-motion';
import { Award, Sparkles, ShieldCheck, Download, Share2, Printer, Trophy, Rocket, ArrowRight } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageLayout } from '@/components/PageLayout';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { EmptyState } from '@/components/EmptyState';
import { fireConfetti } from '@/components/confetti';
import { useApp } from '@/context/AppContext';
import { certId, formatDate, formatMoney } from '@/lib/format';

export function CertificatePage() {
  const navigate = useNavigate();
  const { deal, founder, startups, sound, notify } = useApp();
  const certRef = useRef<HTMLDivElement>(null);
  const [qrUrl, setQrUrl] = useState<string>('');
  const [downloading, setDownloading] = useState(false);

  const startup = startups[0] ?? null;
  const hasCert = deal && startup;

  useEffect(() => {
    if (!hasCert) return;
    let active = true;
    (async () => {
      try {
        const QRCode = (await import('qrcode')).default;
        const payload = `FounderX AI | CEO Certificate\nFounder: ${founder.name}\nCompany: ${startup.name}\nFunding: ${formatMoney(deal!.amount)}\nScore: ${deal!.score}\nID: ${certId(founder.name, startup.name)}`;
        const url = await QRCode.toDataURL(payload, {
          margin: 1,
          width: 200,
          color: { dark: '#0a0c1b', light: '#ffffff' },
        });
        if (active) setQrUrl(url);
      } catch {
        // ignore QR generation errors
      }
    })();
    return () => { active = false; };
  }, [hasCert, founder.name, deal, startup]);

  const downloadPdf = async () => {
    if (!certRef.current) return;
    setDownloading(true);
    sound('click');
    try {
      const [{ default: html2canvas }, jspdfMod] = await Promise.all([
        import('html2canvas'),
        import('jspdf'),
      ]);
      const JsPDFClass = (jspdfMod as unknown as { jsPDF: typeof import('jspdf').jsPDF }).jsPDF;
      const canvas = await html2canvas(certRef.current, {
        backgroundColor: '#04050d',
        scale: 2,
        useCORS: true,
      });
      const img = canvas.toDataURL('image/png');
      const pdf = new JsPDFClass({ orientation: 'landscape', unit: 'px', format: [canvas.width, canvas.height] });
      pdf.addImage(img, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(`FounderX-Certificate-${(founder.name || 'CEO').replace(/\s+/g, '-')}.pdf`);
      notify({ title: 'Certificate downloaded', message: 'Your PDF has been saved.', variant: 'success' });
    } catch {
      notify({ title: 'Download failed', message: 'Could not generate the PDF. Try again.', variant: 'danger' });
    } finally {
      setDownloading(false);
    }
  };

  const share = async () => {
    sound('click');
    const text = `I just became a Founder & CEO with FounderX AI! ${founder.name} · ${startup?.name ?? ''} · Funding: ${deal ? formatMoney(deal.amount, true) : ''}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: 'FounderX AI Certificate', text });
      } catch {
        // user cancelled
      }
    } else {
      try {
        await navigator.clipboard.writeText(text);
        notify({ title: 'Copied', message: 'Certificate summary copied to clipboard.', variant: 'info' });
      } catch {
        notify({ title: 'Share unavailable', message: 'Web Share is not supported here.', variant: 'warning' });
      }
    }
  };

  const print = () => {
    sound('click');
    window.print();
  };

  if (!hasCert) {
    return (
      <PageLayout title="CEO Certificate" subtitle="Your founder credentials" accent="warm">
        <EmptyState
          icon={<Trophy className="h-7 w-7" />}
          title="No certificate yet"
          message="Close a deal in Shark Tank to mint your official CEO certificate."
          action={<GlowButton onClick={() => { sound('click'); navigate('/sharktank'); }}>Open Shark Tank</GlowButton>}
        />
      </PageLayout>
    );
  }

  return (
    <PageLayout title="CEO Certificate" subtitle="Your founder credentials" accent="warm">
      <motion.div initial={{ opacity: 0, scale: 0.94, rotateX: 10 }} animate={{ opacity: 1, scale: 1, rotateX: 0 }} transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}>
        <div className="perspective">
          <div ref={certRef} className="relative overflow-hidden rounded-3xl border border-warning-500/30 bg-gradient-to-br from-ink-850 to-ink-900 p-6 shadow-glow">
            <div className="pointer-events-none absolute left-3 top-3 h-10 w-10 rounded-tl-2xl border-l-2 border-t-2 border-warning-400/50" />
            <div className="pointer-events-none absolute right-3 top-3 h-10 w-10 rounded-tr-2xl border-r-2 border-t-2 border-warning-400/50" />
            <div className="pointer-events-none absolute bottom-3 left-3 h-10 w-10 rounded-bl-2xl border-l-2 border-b-2 border-warning-400/50" />
            <div className="pointer-events-none absolute bottom-3 right-3 h-10 w-10 rounded-br-2xl border-r-2 border-b-2 border-warning-400/50" />

            <div className="text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-brand-gradient shadow-glow">
                <Award className="h-6 w-6 text-white" />
              </div>
              <p className="mt-3 text-[10px] uppercase tracking-[0.3em] text-warning-400">Certificate of Foundership</p>
              <p className="mt-4 text-xs text-brand-200/60">This certifies that</p>
              <h2 className="mt-1 font-display text-3xl font-bold text-gradient-warm">{founder.name || 'Founder'}</h2>
              <p className="mt-3 text-sm text-brand-200/70">is hereby recognized as the</p>
              <p className="mt-1 font-display text-xl font-bold text-white">Chief Executive Officer</p>
              <p className="mt-3 text-sm text-brand-200/70">
                of <span className="font-semibold text-aqua-300">{startup!.name}</span>
              </p>
              {deal && (
                <p className="mt-2 text-xs text-success-400">Funding Raised: {formatMoney(deal.amount)}</p>
              )}

              <div className="mt-5 flex items-center justify-around gap-4">
                <div className="text-left">
                  <div className="space-y-1.5 text-[10px] text-brand-200/60">
                    <p><span className="text-brand-200/40">Company:</span> <span className="text-brand-100/80">{startup!.name}</span></p>
                    <p><span className="text-brand-200/40">Funding:</span> <span className="text-brand-100/80">{formatMoney(deal!.amount, true)}</span></p>
                    <p><span className="text-brand-200/40">Score:</span> <span className="text-brand-100/80">{deal!.score}/100</span></p>
                    <p><span className="text-brand-200/40">Date:</span> <span className="text-brand-100/80">{formatDate(deal!.date)}</span></p>
                  </div>
                  <div className="mt-3 border-t border-white/15 pt-2">
                    <p className="font-display text-sm italic text-gradient">FounderX AI</p>
                    <p className="text-[8px] uppercase tracking-wider text-brand-200/40">CEO Signature</p>
                  </div>
                </div>
                {qrUrl ? (
                  <div className="rounded-2xl bg-white p-2">
                    <img src={qrUrl} alt="Certificate QR code" className="h-24 w-24" />
                    <p className="mt-1 text-center text-[8px] text-ink-900">Scan to verify</p>
                  </div>
                ) : (
                  <div className="flex h-28 w-28 items-center justify-center rounded-2xl bg-white/10">
                    <Sparkles className="h-6 w-6 animate-spin-slow text-brand-200/50" />
                  </div>
                )}
              </div>

              <div className="mt-4 flex items-center justify-center gap-2 text-[10px] text-brand-200/40">
                <ShieldCheck className="h-3.5 w-3.5 text-success-400" /> Verified on FounderX Protocol · {certId(founder.name, startup!.name)}
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      <div className="no-print mt-4 grid grid-cols-3 gap-3">
        <GlowButton variant="ghost" onClick={downloadPdf} disabled={downloading}>
          <Download className="h-4 w-4" /> {downloading ? '...' : 'PDF'}
        </GlowButton>
        <GlowButton variant="aqua" onClick={share}>
          <Share2 className="h-4 w-4" /> Share
        </GlowButton>
        <GlowButton variant="grape" onClick={print}>
          <Printer className="h-4 w-4" /> Print
        </GlowButton>
      </div>

      <AnimatePresence>
        {downloading && (
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="no-print mt-3 flex items-center justify-center gap-2 text-xs text-aqua-300">
            <Sparkles className="h-3.5 w-3.5 animate-spin-slow" /> Generating PDF...
          </motion.p>
        )}
      </AnimatePresence>

      <button
        onClick={() => { sound('click'); fireConfetti(); navigate('/success'); }}
        className="no-print mt-4 flex w-full items-center justify-center gap-2 text-xs text-brand-200/60 transition hover:text-success-400"
      >
        <Trophy className="h-4 w-4" /> View success celebration
      </button>
      <button
        onClick={() => { sound('click'); navigate('/analytics'); }}
        className="no-print mt-2 flex w-full items-center justify-center gap-2 text-xs text-brand-200/60 transition hover:text-aqua-300"
      >
        <Rocket className="h-4 w-4" /> Track your growth <ArrowRight className="h-3.5 w-3.5" />
      </button>
    </PageLayout>
  );
}
