import { motion } from 'framer-motion';
import { Trophy, Rocket, ArrowRight, TrendingUp } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { AnimatedCounter } from '@/components/AnimatedCounter';
import { fireConfetti } from '@/components/confetti';
import { useApp } from '@/context/AppContext';
import { formatMoney } from '@/lib/format';
import { useEffect } from 'react';

export function SuccessPage() {
  const navigate = useNavigate();
  const { deal, founder } = useApp();

  useEffect(() => {
    fireConfetti();
  }, []);

  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col items-center justify-center px-4 py-10 sm:max-w-lg">
      <motion.div
        initial={{ scale: 0.6, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', stiffness: 200 }}
        className="relative"
      >
        <div className="absolute -inset-6 rounded-[2.5rem] bg-brand-gradient opacity-30 blur-2xl" />
        <div className="relative flex h-24 w-24 items-center justify-center rounded-[2rem] bg-brand-gradient shadow-glow">
          <Trophy className="h-12 w-12 text-white" />
        </div>
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="mt-8 text-center font-display text-3xl font-bold"
      >
        <span className="text-gradient-warm">Congratulations!</span>
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.35 }}
        className="mt-2 text-center text-sm text-brand-200/70"
      >
        You are officially a Founder & CEO.
      </motion.p>

      {deal && (
        <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-6 w-full">
          <GlassCard className="p-6 text-center" glow="success">
            <div className="grid grid-cols-3 gap-3">
              <div>
                <p className="text-[10px] uppercase text-brand-200/50">Funding</p>
                <p className="mt-1 font-display text-lg font-bold text-success-400">
                  $<AnimatedCounter value={deal.amount / 1000} suffix="k" />
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase text-brand-200/50">Score</p>
                <p className="mt-1 font-display text-lg font-bold text-gradient">
                  <AnimatedCounter value={deal.score} />
                </p>
              </div>
              <div>
                <p className="text-[10px] uppercase text-brand-200/50">Company</p>
                <p className="mt-1 font-display text-sm font-bold text-white">{deal.startupName}</p>
              </div>
            </div>
          </GlassCard>
        </motion.div>
      )}

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.7 }} className="mt-6 w-full space-y-3">
        <GlowButton fullWidth size="lg" onClick={() => navigate('/certificate')}>
          <Trophy className="h-5 w-5" /> Open Certificate <ArrowRight className="h-4 w-4" />
        </GlowButton>
        <GlowButton fullWidth variant="ghost" onClick={() => navigate('/analytics')}>
          <TrendingUp className="h-4 w-4" /> View Analytics
        </GlowButton>
        <GlowButton fullWidth variant="aqua" onClick={() => navigate('/dashboard')}>
          <Rocket className="h-4 w-4" /> Back to Home
        </GlowButton>
      </motion.div>

      <p className="mt-6 text-[10px] uppercase tracking-[0.3em] text-brand-200/40">
        {founder.name || 'Founder'} · FounderX AI
      </p>
    </div>
  );
}
