import { motion, AnimatePresence } from 'framer-motion';
import { Waves, HandCoins, Check, X, Trophy, RotateCcw, ArrowRight, Lightbulb, Building2, TrendingUp, Shield } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PageLayout } from '@/components/PageLayout';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';
import { EmptyState } from '@/components/EmptyState';
import { AnimatedCounter } from '@/components/AnimatedCounter';
import { TypingText } from '@/components/TypingText';
import { fireConfetti } from '@/components/confetti';
import { useApp } from '@/context/AppContext';
import { generateInvestor, getImprovementTips } from '@/lib/investors';
import { formatMoney } from '@/lib/format';
import type { Deal, Investor } from '@/types';

type Phase = 'idle' | 'connect' | 'feedback' | 'offer' | 'accepted' | 'rejected';

export function SharkTankPage() {
  const navigate = useNavigate();
  const { currentStartup, startups, setInvestor, acceptDeal, sound, deal: existingDeal } = useApp();
  const startup = currentStartup ?? startups[0] ?? null;

  const [phase, setPhase] = useState<Phase>('idle');
  const [investor, setInvestorState] = useState<Investor | null>(null);
  const [typedFeedback, setTypedFeedback] = useState(false);
  const [tips] = useState(() => getImprovementTips());

  if (!startup) {
    return (
      <PageLayout title="Shark Tank AI" subtitle="Pitch to AI investors" accent="grape">
        <EmptyState
          icon={<Waves className="h-7 w-7" />}
          title="No startup to pitch"
          message="Generate a startup first, then come back to pitch it to investors."
          action={<GlowButton onClick={() => { sound('click'); navigate('/generate'); }}>Generate a startup</GlowButton>}
        />
      </PageLayout>
    );
  }

  const connect = () => {
    sound('generate');
    setPhase('connect');
    setTypedFeedback(false);
    setInvestorState(null);
    setTimeout(() => {
      const inv = generateInvestor(startup);
      setInvestorState(inv);
      setInvestor(inv);
      setPhase('feedback');
    }, 2000);
  };

  const showOffer = () => {
    if (!investor) return;
    setPhase(investor.positive ? 'offer' : 'rejected');
    if (!investor.positive) sound('reject');
  };

  const accept = () => {
    if (!investor) return;
    const d: Deal = {
      id: `deal_${Date.now().toString(36)}`,
      startupId: startup.id,
      startupName: startup.name,
      founderName: startup.form.founderName || 'Founder',
      investorName: investor.name,
      amount: investor.amount,
      equity: investor.equity,
      valuation: Math.round(investor.amount / (investor.equity / 100)),
      score: startup.score,
      date: Date.now(),
    };
    acceptDeal(d);
    sound('success');
    fireConfetti();
    setPhase('accepted');
  };

  const reject = () => {
    sound('reject');
    setPhase('rejected');
  };

  return (
    <PageLayout title="Shark Tank AI" subtitle={`Pitching ${startup.name}`} accent="grape">
      <AnimatePresence mode="wait">
        {/* IDLE — pitch button only */}
        {phase === 'idle' && (
          <motion.div key="idle" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <GlassCard className="p-6 text-center" glow="grape" elevated>
              <motion.div
                animate={{ scale: [1, 1.05, 1] }}
                transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
                className="mx-auto flex h-20 w-20 items-center justify-center rounded-[2rem] bg-brand-gradient-hero shadow-glow-lg"
              >
                <Waves className="h-9 w-9 text-white" />
              </motion.div>
              <h2 className="mt-5 font-display text-xl font-bold text-white">Ready to pitch?</h2>
              <p className="mt-2 text-sm text-brand-200/60">
                We'll connect you with a random AI investor. Deliver your pitch for{' '}
                <span className="font-semibold text-grape-300">{startup.name}</span> and see if they bite.
              </p>
              <div className="mt-4 flex items-center justify-center gap-4 text-[11px] text-brand-200/50">
                <span className="flex items-center gap-1.5"><Shield className="h-3.5 w-3.5 text-aqua-300" /> Simulated</span>
                <span className="flex items-center gap-1.5"><TrendingUp className="h-3.5 w-3.5 text-success-400" /> Score: {startup.score}</span>
              </div>
              <div className="mt-5">
                <GlowButton fullWidth size="lg" variant="grape" onClick={connect}>
                  <Waves className="h-5 w-5" /> Open Shark Tank
                </GlowButton>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* CONNECTING */}
        {phase === 'connect' && (
          <motion.div key="connect" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center justify-center py-20">
            <div className="relative">
              <motion.div
                animate={{ scale: [1, 1.12, 1], opacity: [0.7, 1, 0.7] }}
                transition={{ duration: 1.5, repeat: Infinity }}
                className="flex h-24 w-24 items-center justify-center rounded-[2rem] bg-brand-gradient-hero shadow-glow-lg"
              >
                <Waves className="h-11 w-11 text-white" />
              </motion.div>
              {[0, 1, 2].map((r) => (
                <motion.div
                  key={r}
                  className="absolute inset-0 rounded-[2rem] border-2 border-brand-400/40"
                  animate={{ scale: [1, 1.7], opacity: [0.6, 0] }}
                  transition={{ duration: 1.8, repeat: Infinity, delay: r * 0.6 }}
                />
              ))}
            </div>
            <p className="mt-8 font-display text-lg font-bold text-white">Connecting to Investors...</p>
            <div className="mt-3 flex gap-1.5">
              {[0, 1, 2].map((i) => (
                <motion.span key={i} className="h-2 w-2 rounded-full bg-grape-400" animate={{ opacity: [0.3, 1, 0.3], y: [0, -4, 0] }} transition={{ duration: 1, repeat: Infinity, delay: i * 0.18 }} />
              ))}
            </div>
            <p className="mt-4 text-center text-xs text-brand-200/40">Matching your startup with the right investor</p>
          </motion.div>
        )}

        {/* FEEDBACK */}
        {phase === 'feedback' && investor && (
          <motion.div key="feedback" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <GlassCard className="p-5" glow={investor.positive ? 'success' : 'brand'} elevated>
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-brand-gradient-hero text-lg font-bold text-white shadow-glow">
                  {investor.avatar}
                </div>
                <div className="flex-1">
                  <p className="font-display text-lg font-bold text-white">{investor.name}</p>
                  <p className="text-xs text-brand-200/60">{investor.firm}</p>
                  <p className="mt-0.5 text-[11px] text-grape-300">{investor.focus}</p>
                </div>
              </div>
              <div className="mt-4 rounded-2xl bg-white/5 p-4">
                <p className="text-xs uppercase tracking-wider text-brand-200/50">Investor Feedback</p>
                <p className="mt-2 min-h-[3rem] text-sm leading-relaxed text-white">
                  <TypingText text={investor.feedback} speed={20} onDone={() => setTypedFeedback(true)} />
                </p>
              </div>
              {typedFeedback && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-4">
                  <GlowButton fullWidth onClick={showOffer}>
                    {investor.positive ? 'See the offer' : 'Hear the verdict'} <ArrowRight className="h-4 w-4" />
                  </GlowButton>
                </motion.div>
              )}
            </GlassCard>
          </motion.div>
        )}

        {/* OFFER */}
        {phase === 'offer' && investor && (
          <motion.div key="offer" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
            <GlassCard className="overflow-hidden p-0" glow="success" elevated>
              <div className="bg-gradient-to-br from-success-500/20 to-aqua-400/10 p-6 text-center">
                <motion.div initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 200 }}>
                  <HandCoins className="mx-auto h-12 w-12 text-success-400" />
                </motion.div>
                <p className="mt-3 font-display text-xl font-bold text-white">{investor.name} wants to invest</p>
                <p className="mt-1 text-xs text-brand-200/60">{investor.reason}</p>
              </div>
              <div className="p-5">
                <div className="grid grid-cols-3 gap-3 text-center">
                  <div className="rounded-2xl bg-white/5 py-3">
                    <p className="text-[9px] uppercase text-brand-200/50">Investment</p>
                    <p className="mt-0.5 font-display text-lg font-bold text-success-400">
                      $<AnimatedCounter value={investor.amount / 1000} suffix="k" />
                    </p>
                  </div>
                  <div className="rounded-2xl bg-white/5 py-3">
                    <p className="text-[9px] uppercase text-brand-200/50">Equity</p>
                    <p className="mt-0.5 font-display text-lg font-bold text-white">
                      <AnimatedCounter value={investor.equity} decimals={investor.equity % 1 ? 1 : 0} suffix="%" />
                    </p>
                  </div>
                  <div className="rounded-2xl bg-white/5 py-3">
                    <p className="text-[9px] uppercase text-brand-200/50">Valuation</p>
                    <p className="mt-0.5 font-display text-lg font-bold text-gradient">
                      $<AnimatedCounter value={Math.round(investor.amount / (investor.equity / 100) / 1_000_000)} decimals={1} suffix="M" />
                    </p>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <GlowButton variant="ghost" onClick={reject}>
                    <X className="h-4 w-4" /> Reject Deal
                  </GlowButton>
                  <GlowButton variant="success" onClick={accept}>
                    <Check className="h-4 w-4" /> Accept Deal
                  </GlowButton>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* ACCEPTED */}
        {phase === 'accepted' && investor && (
          <motion.div key="accepted" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }}>
            <GlassCard className="overflow-hidden p-0" glow="success" elevated>
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ type: 'spring', stiffness: 180 }}
                className="bg-gradient-to-br from-success-500/25 to-grape-500/15 p-8 text-center"
              >
                <motion.div
                  initial={{ rotate: -12, scale: 0.8 }}
                  animate={{ rotate: 0, scale: 1 }}
                  transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
                  className="mx-auto flex h-20 w-20 items-center justify-center rounded-3xl border-2 border-success-400 bg-success-500/20"
                >
                  <Check className="h-10 w-10 text-success-400" />
                </motion.div>
                <p className="mt-4 font-display text-2xl font-bold text-white">Deal Approved!</p>
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 }}
                  className="mt-4 inline-block rounded-2xl border-2 border-success-400/50 bg-ink-900/60 px-6 py-2"
                >
                  <span className="font-display text-sm font-bold uppercase tracking-widest text-success-400">Deal Approved</span>
                </motion.div>
              </motion.div>
              <div className="p-5">
                <div className="text-center">
                  <p className="text-xs uppercase tracking-wider text-brand-200/50">Funding Secured</p>
                  <p className="mt-1 font-display text-4xl font-bold text-success-400">
                    $<AnimatedCounter value={investor.amount / 1000} suffix="k" />
                  </p>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <div className="rounded-2xl bg-white/5 p-3 text-center">
                    <p className="text-[10px] uppercase text-brand-200/50">Equity Given</p>
                    <p className="mt-0.5 font-display text-lg font-bold text-white">{investor.equity}%</p>
                  </div>
                  <div className="rounded-2xl bg-white/5 p-3 text-center">
                    <p className="text-[10px] uppercase text-brand-200/50">Valuation</p>
                    <p className="mt-0.5 font-display text-lg font-bold text-gradient">{formatMoney(Math.round(investor.amount / (investor.equity / 100)), true)}</p>
                  </div>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3">
                  <GlowButton variant="ghost" onClick={connect}>
                    <RotateCcw className="h-4 w-4" /> Pitch again
                  </GlowButton>
                  <GlowButton variant="success" onClick={() => { sound('click'); navigate('/certificate'); }}>
                    <Trophy className="h-4 w-4" /> Open Certificate <ArrowRight className="h-3.5 w-3.5" />
                  </GlowButton>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* REJECTED */}
        {phase === 'rejected' && (
          <motion.div key="rejected" initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
            <GlassCard className="p-5" glow="brand">
              <div className="text-center">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-3xl bg-danger-500/15">
                  <X className="h-7 w-7 text-danger-400" />
                </div>
                <p className="mt-3 font-display text-lg font-bold text-white">
                  {investor && !investor.positive ? 'Investor passed' : 'You rejected the deal'}
                </p>
                <p className="mt-1 text-sm text-brand-200/60">
                  {investor && !investor.positive ? investor.feedback : 'No worries — refine and pitch again.'}
                </p>
              </div>
              <div className="mt-5">
                <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider text-warning-400">
                  <Lightbulb className="h-3.5 w-3.5" /> Improvement Tips
                </p>
                <div className="space-y-2">
                  {tips.map((t, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -12 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.1 }}
                      className="flex items-start gap-2 rounded-2xl bg-white/5 p-3 text-sm text-brand-100/90"
                    >
                      <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-warning-400" />
                      {t}
                    </motion.div>
                  ))}
                </div>
              </div>
              <div className="mt-5 grid grid-cols-2 gap-3">
                <GlowButton variant="ghost" onClick={connect}>
                  <RotateCcw className="h-4 w-4" /> Pitch again
                </GlowButton>
                <GlowButton variant="aqua" onClick={() => { sound('click'); navigate('/coach'); }}>
                  <Building2 className="h-4 w-4" /> Back to Coach
                </GlowButton>
              </div>
            </GlassCard>
          </motion.div>
        )}
      </AnimatePresence>

      {existingDeal && phase !== 'accepted' && (
        <button
          onClick={() => { sound('click'); navigate('/certificate'); }}
          className="mt-4 flex w-full items-center justify-center gap-2 text-xs text-brand-200/60 transition hover:text-warning-400"
        >
          <Trophy className="h-4 w-4" /> View your existing deal certificate
        </button>
      )}

      <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-[10px] text-brand-200/40">
        <Waves className="h-3 w-3" /> Simulated negotiation. No real investments are made.
      </p>
    </PageLayout>
  );
}
