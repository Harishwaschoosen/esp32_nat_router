import { motion } from 'framer-motion';
import { Rocket, Sparkles, Brain, Waves, Award, BarChart3, Heart, ArrowRight, Target } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { PageLayout } from '@/components/PageLayout';
import { useApp } from '@/context/AppContext';
import { GlassCard } from '@/components/GlassCard';
import { GlowButton } from '@/components/GlowButton';

const features = [
  { icon: Sparkles, title: 'Startup Generator', desc: 'AI builds a full venture in under 60 seconds.' },
  { icon: Brain, title: 'AI Coach', desc: 'SWOT analysis, metrics, and a startup score.' },
  { icon: Waves, title: 'Shark Tank AI', desc: 'Pitch to simulated investors and close a deal.' },
  { icon: Award, title: 'CEO Certificate', desc: 'Mint a verifiable PDF certificate with a QR code.' },
  { icon: BarChart3, title: 'Analytics', desc: 'Revenue, profit, and growth charts that animate.' },
];

export function AboutPage() {
  const navigate = useNavigate();
  const { sound } = useApp();

  return (
    <PageLayout title="About" subtitle="The FounderX mission" accent="grape">
      <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
        <GlassCard className="flex flex-col items-center p-6 text-center" glow="grape">
          <div className="relative">
            <div className="absolute -inset-4 rounded-[2rem] bg-brand-gradient opacity-25 blur-2xl" />
            <div className="relative flex h-16 w-16 items-center justify-center rounded-3xl bg-brand-gradient shadow-glow">
              <Rocket className="h-8 w-8 text-white" />
            </div>
          </div>
          <h2 className="mt-4 font-display text-2xl font-bold text-gradient">FounderX AI</h2>
          <p className="mt-2 text-sm text-brand-200/70">
            Helping anyone become an entrepreneur in under 60 seconds.
          </p>
          <p className="mt-3 text-xs leading-relaxed text-brand-200/60">
            FounderX AI turns a single idea into a validated startup — complete with a business model,
            SWOT analysis, investor pitch, and a CEO certificate. No code, no spreadsheets, no MBA required.
          </p>
        </GlassCard>
      </motion.div>

      <h2 className="mb-3 mt-6 flex items-center gap-2 text-sm font-semibold text-brand-200/80">
        <Target className="h-4 w-4 text-aqua-300" /> What's inside
      </h2>
      <div className="space-y-3">
        {features.map((f, i) => {
          const Icon = f.icon;
          return (
            <motion.div key={f.title} initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.08 }}>
              <GlassCard className="flex items-center gap-4 p-4" hover>
                <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/5">
                  <Icon className="h-5 w-5 text-aqua-300" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-semibold text-white">{f.title}</p>
                  <p className="text-[11px] text-brand-200/60">{f.desc}</p>
                </div>
              </GlassCard>
            </motion.div>
          );
        })}
      </div>

      <GlassCard className="mt-4 flex items-center justify-center gap-2 p-4 text-center">
        <Heart className="h-4 w-4 text-danger-400" />
        <p className="text-xs text-brand-200/70">Built for dreamers, builders, and future CEOs.</p>
      </GlassCard>

      <div className="mt-6">
        <GlowButton fullWidth size="lg" onClick={() => { sound('click'); navigate('/generate'); }}>
          <Sparkles className="h-5 w-5" /> Start building <ArrowRight className="h-4 w-4" />
        </GlowButton>
      </div>

      <p className="mt-4 text-center text-[10px] text-brand-200/40">FounderX AI · v1.0.0 · Powered by FounderX Intelligence</p>
    </PageLayout>
  );
}
