import { motion } from 'framer-motion';
import { Compass, Home } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { GlowButton } from '@/components/GlowButton';

export function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <div className="mx-auto flex min-h-screen w-full max-w-md flex-col items-center justify-center px-6 text-center sm:max-w-lg">
      <motion.div
        initial={{ scale: 0.6, opacity: 0, rotate: -10 }}
        animate={{ scale: 1, opacity: 1, rotate: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative"
      >
        <div className="absolute -inset-5 rounded-[2.5rem] bg-brand-gradient opacity-25 blur-2xl" />
        <div className="relative flex h-24 w-24 items-center justify-center rounded-[2rem] bg-brand-gradient shadow-glow">
          <Compass className="h-12 w-12 text-white" />
        </div>
      </motion.div>

      <motion.h1
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.25 }}
        className="mt-8 font-display text-6xl font-bold text-gradient"
      >
        404
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4 }}
        className="mt-2 text-sm text-brand-200/70"
      >
        This page drifted off the cap table. Let's get you back.
      </motion.p>

      <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.55 }} className="mt-8">
        <GlowButton size="lg" onClick={() => navigate('/dashboard')}>
          <Home className="h-5 w-5" /> Back to Home
        </GlowButton>
      </motion.div>
    </div>
  );
}
