export type Route =
  | '/'
  | '/dashboard'
  | '/generate'
  | '/coach'
  | '/sharktank'
  | '/certificate'
  | '/analytics'
  | '/profile'
  | '/settings'
  | '/about'
  | '/success';

export type ExperienceLevel = 'Beginner' | 'Intermediate' | 'Experienced' | 'Serial Founder';

export type Difficulty = 'Easy' | 'Medium' | 'Hard' | 'Very Hard';

export interface StartupForm {
  founderName: string;
  idea: string;
  industry: string;
  budget: number;
  country: string;
  targetCustomers: string;
  experience: ExperienceLevel;
}

export interface Startup {
  id: string;
  createdAt: number;
  form: StartupForm;
  name: string;
  problem: string;
  solution: string;
  targetCustomers: string;
  businessModel: string;
  revenueStreams: string[];
  startupCost: number;
  monthlyRevenue: number;
  marketingPlan: string;
  teamSize: number;
  fundingRequired: number;
  difficulty: Difficulty;
  successProbability: number;
  score: number;
  swot: {
    strengths: string[];
    weaknesses: string[];
    opportunities: string[];
    threats: string[];
  };
  metrics: {
    startupCost: number;
    marketSize: string;
    competition: string;
    riskLevel: string;
    marketingStrategy: string;
    fundingAdvice: string;
    breakEvenTime: string;
  };
}

export interface Investor {
  id: string;
  name: string;
  avatar: string;
  firm: string;
  focus: string;
  feedback: string;
  amount: number;
  equity: number;
  reason: string;
  positive: boolean;
}

export interface Deal {
  id: string;
  startupId: string;
  startupName: string;
  founderName: string;
  investorName: string;
  amount: number;
  equity: number;
  valuation: number;
  score: number;
  date: number;
}

export interface Founder {
  name: string;
  company?: string;
  photo?: string;
}

export interface Settings {
  darkMode: boolean;
  sound: boolean;
  notifications: boolean;
}

export interface AppState {
  startups: Startup[];
  currentStartup: Startup | null;
  currentInvestor: Investor | null;
  deal: Deal | null;
  founder: Founder;
  settings: Settings;
}
