import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type { AppState, Deal, Founder, Investor, Settings, Startup } from '@/types';
import {
  addStartup as addStartupFn,
  clearCurrent as clearCurrentFn,
  closeDeal as closeDealFn,
  defaultState,
  loadState,
  resetAll,
  saveState,
  updateFounder as updateFounderFn,
  updateSettings as updateSettingsFn,
} from '@/lib/store';
import { play } from '@/lib/sound';

export interface Toast {
  id: string;
  title: string;
  message?: string;
  variant: 'info' | 'success' | 'warning' | 'danger';
}

interface AppContextValue extends AppState {
  saveStartup: (s: Startup) => void;
  setCurrentStartup: (s: Startup | null) => void;
  setInvestor: (i: Investor | null) => void;
  acceptDeal: (d: Deal) => void;
  clearCurrent: () => void;
  setFounder: (f: Founder) => void;
  setSettings: (s: Partial<Settings>) => void;
  hardReset: () => void;
  toasts: Toast[];
  notify: (t: Omit<Toast, 'id'>) => void;
  dismissToast: (id: string) => void;
  sound: (s: 'click' | 'success' | 'generate' | 'reject' | 'toggle') => void;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(() => loadState());
  const [toasts, setToasts] = useState<Toast[]>([]);
  const timers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});

  useEffect(() => {
    saveState(state);
  }, [state]);

  const dismissToast = useCallback((id: string) => {
    setToasts((t) => t.filter((x) => x.id !== id));
    if (timers.current[id]) {
      clearTimeout(timers.current[id]);
      delete timers.current[id];
    }
  }, []);

  const notify = useCallback(
    (t: Omit<Toast, 'id'>) => {
      const id = `t_${Date.now()}_${Math.floor(Math.random() * 1000)}`;
      setToasts((prev) => [...prev, { ...t, id }]);
      timers.current[id] = setTimeout(() => dismissToast(id), 3600);
    },
    [dismissToast],
  );

  const sound = useCallback(
    (s: 'click' | 'success' | 'generate' | 'reject' | 'toggle') => {
      play(s, state.settings.sound);
    },
    [state.settings.sound],
  );

  const value = useMemo<AppContextValue>(
    () => ({
      ...state,
      saveStartup: (s) => {
        setState((prev) => addStartupFn(prev, s));
        sound('success');
      },
      setCurrentStartup: (s) => setState((prev) => ({ ...prev, currentStartup: s })),
      setInvestor: (i) => setState((prev) => ({ ...prev, currentInvestor: i })),
      acceptDeal: (d) => {
        setState((prev) => closeDealFn(prev, d));
        sound('success');
      },
      clearCurrent: () => setState((prev) => clearCurrentFn(prev)),
      setFounder: (f) => setState((prev) => updateFounderFn(prev, f)),
      setSettings: (s) => setState((prev) => updateSettingsFn(prev, s)),
      hardReset: () => {
        resetAll();
        setState(defaultState());
        notify({ title: 'Data cleared', message: 'Your FounderX profile has been reset.', variant: 'info' });
      },
      toasts,
      notify,
      dismissToast,
      sound,
    }),
    [state, toasts, notify, dismissToast, sound],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}
