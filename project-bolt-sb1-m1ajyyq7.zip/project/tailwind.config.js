/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Sora', 'ui-sans-serif', 'system-ui', 'sans-serif'],
        display: ['Space Grotesk', 'Sora', 'sans-serif'],
        mono: ['JetBrains Mono', 'ui-monospace', 'monospace'],
      },
      colors: {
        ink: {
          950: '#04050d',
          900: '#080a18',
          850: '#0c0f22',
          800: '#11152e',
          700: '#1a1f44',
          600: '#262d63',
        },
        brand: {
          50: '#eef1ff',
          100: '#e0e5ff',
          200: '#c7d0ff',
          300: '#a5b2ff',
          400: '#7c8cff',
          500: '#5b66ff',
          600: '#4a3ff0',
          700: '#3b30d4',
          800: '#2f29a8',
          900: '#2a2585',
        },
        grape: {
          300: '#c4b5fd',
          400: '#a78bfa',
          500: '#8b5cf6',
          600: '#7c3aed',
          700: '#6d28d9',
        },
        aqua: {
          300: '#5cf2ff',
          400: '#22e3f0',
          500: '#06c9d8',
          600: '#0aa6b4',
        },
        success: {
          400: '#34f5b0',
          500: '#10d97e',
          600: '#0bb568',
        },
        warning: {
          400: '#ffd166',
          500: '#ffb020',
        },
        danger: {
          400: '#ff6b8a',
          500: '#ff3d6e',
        },
      },
      boxShadow: {
        glow: '0 0 24px rgba(91,102,255,0.5), 0 0 56px rgba(124,140,255,0.25)',
        'glow-lg': '0 0 40px rgba(91,102,255,0.6), 0 0 80px rgba(139,92,246,0.3)',
        'glow-aqua': '0 0 24px rgba(34,227,240,0.45), 0 0 56px rgba(34,227,240,0.2)',
        'glow-success': '0 0 24px rgba(16,217,126,0.5), 0 0 56px rgba(16,217,126,0.22)',
        'glow-grape': '0 0 26px rgba(139,92,246,0.55), 0 0 60px rgba(139,92,246,0.25)',
        'glow-danger': '0 0 24px rgba(255,61,110,0.45), 0 0 48px rgba(255,61,110,0.2)',
        'inner-glass': 'inset 0 1px 0 rgba(255,255,255,0.1)',
        'card': '0 8px 32px rgba(4,5,13,0.4), inset 0 1px 0 rgba(255,255,255,0.06)',
        'card-hover': '0 20px 60px -12px rgba(4,5,13,0.7), inset 0 1px 0 rgba(255,255,255,0.1)',
      },
      backgroundImage: {
        'brand-gradient': 'linear-gradient(135deg, #5b66ff 0%, #7c8cff 45%, #8b5cf6 100%)',
        'brand-gradient-2': 'linear-gradient(135deg, #7c8cff 0%, #8b5cf6 55%, #22e3f0 100%)',
        'brand-gradient-hero': 'linear-gradient(135deg, #5b66ff 0%, #8b5cf6 50%, #22e3f0 100%)',
        'brand-gradient-soft': 'linear-gradient(135deg, rgba(91,102,255,0.18) 0%, rgba(139,92,246,0.12) 100%)',
        'gold-gradient': 'linear-gradient(135deg, #ffd166 0%, #ffb020 50%, #ff6b8a 100%)',
      },
      keyframes: {
        float: {
          '0%, 100%': { transform: 'translateY(0) translateX(0)' },
          '50%': { transform: 'translateY(-20px) translateX(12px)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-700px 0' },
          '100%': { backgroundPosition: '700px 0' },
        },
        'pulse-glow': {
          '0%, 100%': { boxShadow: '0 0 20px rgba(91,102,255,0.45), 0 0 40px rgba(124,140,255,0.2)' },
          '50%': { boxShadow: '0 0 44px rgba(124,140,255,0.8), 0 0 88px rgba(139,92,246,0.35)' },
        },
        'spin-slow': { to: { transform: 'rotate(360deg)' } },
        'caret-blink': { '0%, 100%': { opacity: '1' }, '50%': { opacity: '0' } },
        'shimmer-line': {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(100%)' },
        },
        'rise': {
          '0%': { transform: 'translateY(8px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' },
        },
      },
      animation: {
        float: 'float 9s ease-in-out infinite',
        shimmer: 'shimmer 2.2s linear infinite',
        'pulse-glow': 'pulse-glow 3s ease-in-out infinite',
        'spin-slow': 'spin-slow 1.4s linear infinite',
        'caret-blink': 'caret-blink 0.9s steps(2) infinite',
        'shimmer-line': 'shimmer-line 2.5s ease-in-out infinite',
        'rise': 'rise 0.5s ease-out forwards',
      },
    },
  },
  plugins: [],
};
